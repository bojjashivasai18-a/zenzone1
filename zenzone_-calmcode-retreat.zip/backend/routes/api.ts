import { Router } from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { getDb, DEFAULT_PREFERENCES } from '../database/db.ts';
import { moderateCalmMessage } from '../services/moderationService.ts';
import { generateExamAffirmation, hasConfiguredAiKey } from '../services/affirmationService.ts';
import type {
  AffirmationSituation,
  CampusCalmMessage,
  FavoriteAffirmation,
  MeditationSession,
  MoodLog,
  UserPreferences,
  WeeklyStressPoint,
} from '../../shared/types/zenzone.ts';

const VALID_SITUATIONS = new Set<AffirmationSituation>([
  'before-exam',
  'imposter-syndrome',
  'late-night-fatigue',
  'result-anxiety',
  'general-confidence',
]);

const VALID_EMOJIS = new Set(['😌', '🙂', '😐', '😟', '😫']);

function buildWeeklyTrend(logs: MoodLog[]): WeeklyStressPoint[] {
  const today = new Date();
  const points: WeeklyStressPoint[] = [];

  for (let offset = 6; offset >= 0; offset--) {
    const d = new Date(today);
    d.setDate(today.getDate() - offset);
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    const dateKey = `${yyyy}-${mm}-${dd}`;
    const label = d.toLocaleDateString('en-US', { weekday: 'short' });

    const dayLogs = logs.filter((entry) => entry.created_at.slice(0, 10) === dateKey);
    const avgStress =
      dayLogs.length > 0
        ? Number(
            (dayLogs.reduce((sum, item) => sum + item.stress_level, 0) / dayLogs.length).toFixed(2)
          )
        : null;

    points.push({
      date: dateKey,
      label,
      avgStress,
      entryCount: dayLogs.length,
    });
  }

  return points;
}

function calculateMeditationStreak(sessions: MeditationSession[]): number {
  const completedDates = new Set(
    sessions
      .filter((s) => s.completed)
      .map((s) => s.session_date.slice(0, 10))
  );

  if (completedDates.size === 0) return 0;

  const today = new Date();
  const formatKey = (d: Date) => {
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
  };

  let streak = 0;
  const cursor = new Date(today);

  // Allow streak to start from today or yesterday if today hasn't been logged yet
  if (!completedDates.has(formatKey(cursor))) {
    cursor.setDate(cursor.getDate() - 1);
    if (!completedDates.has(formatKey(cursor))) {
      return 0;
    }
  }

  while (completedDates.has(formatKey(cursor))) {
    streak += 1;
    cursor.setDate(cursor.getDate() - 1);
  }

  return streak;
}

export function createApiRouter(): Router {
  const router = Router();
  const db = getDb();

  router.get('/health', (_req, res) => {
    res.json({ ok: true, aiConfigured: hasConfiguredAiKey() });
  });

  // Profile & Preferences
  router.get('/profile', (_req, res) => {
    const profile = db
      .prepare('SELECT id, username, created_at, preferences FROM user_profiles ORDER BY id ASC LIMIT 1')
      .get() as { id: number; username: string; created_at: string; preferences: string } | undefined;

    if (!profile) {
      res.status(404).json({ error: 'User profile not found.' });
      return;
    }

    let parsedPrefs: UserPreferences = DEFAULT_PREFERENCES;
    try {
      parsedPrefs = { ...DEFAULT_PREFERENCES, ...JSON.parse(profile.preferences) };
    } catch {
      parsedPrefs = DEFAULT_PREFERENCES;
    }

    res.json({
      id: profile.id,
      username: profile.username,
      created_at: profile.created_at,
      preferences: parsedPrefs,
    });
  });

  router.put('/profile', (req, res) => {
    const { username, preferences } = req.body as {
      username?: unknown;
      preferences?: Partial<UserPreferences>;
    };

    const profile = db
      .prepare('SELECT id, username, preferences FROM user_profiles ORDER BY id ASC LIMIT 1')
      .get() as { id: number; username: string; preferences: string } | undefined;

    if (!profile) {
      res.status(404).json({ error: 'Profile not found.' });
      return;
    }

    const cleanUsername =
      typeof username === 'string' && username.trim().length > 0
        ? username.trim().slice(0, 32)
        : profile.username;

    let currentPrefs = DEFAULT_PREFERENCES;
    try {
      currentPrefs = { ...DEFAULT_PREFERENCES, ...JSON.parse(profile.preferences) };
    } catch {
      currentPrefs = DEFAULT_PREFERENCES;
    }

    const nextPrefs: UserPreferences = {
      ...currentPrefs,
      ...(preferences && typeof preferences === 'object' ? preferences : {}),
      soundVolumes: {
        ...currentPrefs.soundVolumes,
        ...(preferences?.soundVolumes && typeof preferences.soundVolumes === 'object'
          ? preferences.soundVolumes
          : {}),
      },
    };

    db.prepare('UPDATE user_profiles SET username = ?, preferences = ? WHERE id = ?').run(
      cleanUsername,
      JSON.stringify(nextPrefs),
      profile.id
    );

    db.prepare(
      `UPDATE user_preferences
       SET study_interval_minutes = ?,
           preferred_meditation_minutes = ?,
           breathing_chimes_enabled = ?,
           sound_volumes = ?,
           binaural_frequency_hz = ?,
           binaural_volume = ?,
           updated_at = datetime('now')
       WHERE profile_id = ?`
    ).run(
      nextPrefs.studyIntervalMinutes,
      nextPrefs.preferredMeditationMinutes,
      nextPrefs.breathingChimesEnabled ? 1 : 0,
      JSON.stringify(nextPrefs.soundVolumes),
      nextPrefs.binauralFrequencyHz,
      nextPrefs.binauralVolume,
      profile.id
    );

    res.json({
      id: profile.id,
      username: cleanUsername,
      preferences: nextPrefs,
    });
  });

  // Mood Logs & Weekly Trends
  router.get('/moods', (_req, res) => {
    const logs = db
      .prepare('SELECT id, stress_level, mood_emoji, reflection, created_at FROM mood_logs ORDER BY created_at DESC, id DESC')
      .all() as MoodLog[];

    const weeklyTrend = buildWeeklyTrend(logs);
    res.json({ logs, weeklyTrend });
  });

  router.post('/moods', (req, res) => {
    const { stress_level, mood_emoji, reflection, created_at } = req.body as {
      stress_level?: unknown;
      mood_emoji?: unknown;
      reflection?: unknown;
      created_at?: unknown;
    };

    const stress = Number(stress_level);
    if (!Number.isInteger(stress) || stress < 1 || stress > 5) {
      res.status(400).json({ error: 'Stress level must be an integer between 1 and 5.' });
      return;
    }

    const emoji = typeof mood_emoji === 'string' && VALID_EMOJIS.has(mood_emoji) ? mood_emoji : '😌';
    const cleanReflection =
      typeof reflection === 'string' ? reflection.trim().slice(0, 600) : '';

    // Allow client local ISO date prefix if provided safely, otherwise current local-friendly timestamp
    const timestamp =
      typeof created_at === 'string' && /^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}/.test(created_at)
        ? created_at.slice(0, 19).replace('T', ' ')
        : new Date().toISOString().slice(0, 19).replace('T', ' ');

    const result = db
      .prepare(
        'INSERT INTO mood_logs (stress_level, mood_emoji, reflection, created_at) VALUES (?, ?, ?, ?)'
      )
      .run(stress, emoji, cleanReflection, timestamp);

    const created = db
      .prepare('SELECT id, stress_level, mood_emoji, reflection, created_at FROM mood_logs WHERE id = ?')
      .get(result.lastInsertRowid) as MoodLog;

    const allLogs = db
      .prepare('SELECT id, stress_level, mood_emoji, reflection, created_at FROM mood_logs ORDER BY created_at DESC, id DESC')
      .all() as MoodLog[];

    res.status(201).json({
      entry: created,
      logs: allLogs,
      weeklyTrend: buildWeeklyTrend(allLogs),
    });
  });

  router.put('/moods/:id', (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id <= 0) {
      res.status(400).json({ error: 'Invalid mood entry id.' });
      return;
    }

    const { stress_level, mood_emoji, reflection } = req.body as {
      stress_level?: unknown;
      mood_emoji?: unknown;
      reflection?: unknown;
    };

    const stress = Number(stress_level);
    if (!Number.isInteger(stress) || stress < 1 || stress > 5) {
      res.status(400).json({ error: 'Stress level must be an integer between 1 and 5.' });
      return;
    }

    const emoji = typeof mood_emoji === 'string' && VALID_EMOJIS.has(mood_emoji) ? mood_emoji : '😌';
    const cleanReflection =
      typeof reflection === 'string' ? reflection.trim().slice(0, 600) : '';

    const info = db
      .prepare('UPDATE mood_logs SET stress_level = ?, mood_emoji = ?, reflection = ? WHERE id = ?')
      .run(stress, emoji, cleanReflection, id);

    if (info.changes === 0) {
      res.status(404).json({ error: 'Mood entry not found.' });
      return;
    }

    const allLogs = db
      .prepare('SELECT id, stress_level, mood_emoji, reflection, created_at FROM mood_logs ORDER BY created_at DESC, id DESC')
      .all() as MoodLog[];

    res.json({ logs: allLogs, weeklyTrend: buildWeeklyTrend(allLogs) });
  });

  router.delete('/moods/:id', (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id <= 0) {
      res.status(400).json({ error: 'Invalid mood entry id.' });
      return;
    }

    const info = db.prepare('DELETE FROM mood_logs WHERE id = ?').run(id);
    if (info.changes === 0) {
      res.status(404).json({ error: 'Mood entry not found.' });
      return;
    }

    const allLogs = db
      .prepare('SELECT id, stress_level, mood_emoji, reflection, created_at FROM mood_logs ORDER BY created_at DESC, id DESC')
      .all() as MoodLog[];

    res.json({ logs: allLogs, weeklyTrend: buildWeeklyTrend(allLogs) });
  });

  // Meditation Sessions & Streaks
  router.get('/meditations', (_req, res) => {
    const raw = db
      .prepare('SELECT id, duration, completed, session_date FROM meditation_sessions ORDER BY session_date DESC, id DESC')
      .all() as Array<{ id: number; duration: number; completed: number; session_date: string }>;

    const sessions: MeditationSession[] = raw.map((row) => ({
      ...row,
      completed: Boolean(row.completed),
    }));

    const totalMinutes = sessions
      .filter((s) => s.completed)
      .reduce((sum, s) => sum + Math.round(s.duration / 60), 0);

    res.json({
      sessions,
      currentStreak: calculateMeditationStreak(sessions),
      totalMinutes,
      totalSessions: sessions.filter((s) => s.completed).length,
    });
  });

  router.post('/meditations', (req, res) => {
    const { duration, completed, session_date } = req.body as {
      duration?: unknown;
      completed?: unknown;
      session_date?: unknown;
    };

    const durationSec = Number(duration);
    if (!Number.isInteger(durationSec) || durationSec <= 0 || durationSec > 7200) {
      res.status(400).json({ error: 'Duration must be a positive number of seconds.' });
      return;
    }

    const isCompleted = completed === false ? 0 : 1;
    const timestamp =
      typeof session_date === 'string' && /^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}/.test(session_date)
        ? session_date.slice(0, 19).replace('T', ' ')
        : new Date().toISOString().slice(0, 19).replace('T', ' ');

    db.prepare(
      'INSERT INTO meditation_sessions (duration, completed, session_date) VALUES (?, ?, ?)'
    ).run(durationSec, isCompleted, timestamp);

    const raw = db
      .prepare('SELECT id, duration, completed, session_date FROM meditation_sessions ORDER BY session_date DESC, id DESC')
      .all() as Array<{ id: number; duration: number; completed: number; session_date: string }>;

    const sessions: MeditationSession[] = raw.map((row) => ({
      ...row,
      completed: Boolean(row.completed),
    }));

    const totalMinutes = sessions
      .filter((s) => s.completed)
      .reduce((sum, s) => sum + Math.round(s.duration / 60), 0);

    res.status(201).json({
      sessions,
      currentStreak: calculateMeditationStreak(sessions),
      totalMinutes,
      totalSessions: sessions.filter((s) => s.completed).length,
    });
  });

  // Exam Affirmations
  router.get('/affirmations', (_req, res) => {
    const favorites = db
      .prepare('SELECT id, affirmation, situation, source, created_at FROM favorite_affirmations ORDER BY created_at DESC, id DESC')
      .all() as FavoriteAffirmation[];

    res.json({
      favorites,
      aiConfigured: hasConfiguredAiKey(),
    });
  });

  router.post('/affirmations/generate', async (req, res) => {
    const { situation, lastAffirmation } = req.body as {
      situation?: unknown;
      lastAffirmation?: unknown;
    };

    const selectedSituation: AffirmationSituation =
      typeof situation === 'string' && VALID_SITUATIONS.has(situation as AffirmationSituation)
        ? (situation as AffirmationSituation)
        : 'general-confidence';

    const previous = typeof lastAffirmation === 'string' ? lastAffirmation : undefined;
    const result = await generateExamAffirmation(selectedSituation, previous);
    res.json(result);
  });

  router.post('/affirmations/favorites', (req, res) => {
    const { affirmation, situation, source } = req.body as {
      affirmation?: unknown;
      situation?: unknown;
      source?: unknown;
    };

    if (typeof affirmation !== 'string' || affirmation.trim().length < 8) {
      res.status(400).json({ error: 'Affirmation text is required.' });
      return;
    }

    const cleanAffirmation = affirmation.trim().slice(0, 320);
    const cleanSituation: AffirmationSituation =
      typeof situation === 'string' && VALID_SITUATIONS.has(situation as AffirmationSituation)
        ? (situation as AffirmationSituation)
        : 'general-confidence';
    const cleanSource = source === 'gemini' ? 'gemini' : 'local';

    // Avoid duplicate saved favorite
    const existing = db
      .prepare('SELECT id FROM favorite_affirmations WHERE affirmation = ? LIMIT 1')
      .get(cleanAffirmation);

    if (!existing) {
      db.prepare(
        'INSERT INTO favorite_affirmations (affirmation, situation, source) VALUES (?, ?, ?)'
      ).run(cleanAffirmation, cleanSituation, cleanSource);
    }

    const favorites = db
      .prepare('SELECT id, affirmation, situation, source, created_at FROM favorite_affirmations ORDER BY created_at DESC, id DESC')
      .all() as FavoriteAffirmation[];

    res.status(201).json({ favorites });
  });

  router.delete('/affirmations/favorites/:id', (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id <= 0) {
      res.status(400).json({ error: 'Invalid favorite id.' });
      return;
    }

    db.prepare('DELETE FROM favorite_affirmations WHERE id = ?').run(id);
    const favorites = db
      .prepare('SELECT id, affirmation, situation, source, created_at FROM favorite_affirmations ORDER BY created_at DESC, id DESC')
      .all() as FavoriteAffirmation[];

    res.json({ favorites });
  });

  // Anonymous Campus Calm Wall
  router.get('/calm-wall', (_req, res) => {
    const messages = db
      .prepare('SELECT id, message, topic, support_count, created_at FROM campus_calm_messages ORDER BY created_at DESC, id DESC LIMIT 60')
      .all() as CampusCalmMessage[];

    res.json({ messages });
  });

  router.post('/calm-wall', (req, res) => {
    const { message, topic } = req.body as { message?: unknown; topic?: unknown };
    const moderated = moderateCalmMessage(message, topic);

    if (!moderated.valid) {
      res.status(400).json({ error: moderated.error });
      return;
    }

    const result = db
      .prepare('INSERT INTO campus_calm_messages (message, topic, support_count) VALUES (?, ?, 0)')
      .run(moderated.sanitizedMessage, moderated.sanitizedTopic);

    const created = db
      .prepare('SELECT id, message, topic, support_count, created_at FROM campus_calm_messages WHERE id = ?')
      .get(result.lastInsertRowid) as CampusCalmMessage;

    res.status(201).json({ entry: created });
  });

  router.post('/calm-wall/:id/support', (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id <= 0) {
      res.status(400).json({ error: 'Invalid message id.' });
      return;
    }

    const info = db
      .prepare('UPDATE campus_calm_messages SET support_count = support_count + 1 WHERE id = ?')
      .run(id);

    if (info.changes === 0) {
      res.status(404).json({ error: 'Message not found.' });
      return;
    }

    const updated = db
      .prepare('SELECT id, message, topic, support_count, created_at FROM campus_calm_messages WHERE id = ?')
      .get(id) as CampusCalmMessage;

    res.json({ entry: updated });
  });

  // Sample Datasets
  router.get('/datasets/yoga', (_req, res) => {
    const filePath = path.resolve(process.cwd(), 'src', 'data', 'yogaPoses.json');
    const data = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
    res.json({ poses: data });
  });

  router.get('/datasets/prompts', (_req, res) => {
    const filePath = path.resolve(process.cwd(), 'src', 'data', 'reflectionPrompts.json');
    const data = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
    res.json({ prompts: data });
  });

  return router;
}
