import Database from 'better-sqlite3';
import fs from 'node:fs';
import path from 'node:path';
import type { UserPreferences } from '../../shared/types/zenzone.ts';

const DB_DIR = path.resolve(process.cwd(), 'data');
const DB_PATH = path.join(DB_DIR, 'zenzone.db');
const INIT_SQL_PATH = path.resolve(process.cwd(), 'backend', 'database', 'init.sql');

export const DEFAULT_PREFERENCES: UserPreferences = {
  studyIntervalMinutes: 45,
  preferredMeditationMinutes: 5,
  breathingChimesEnabled: true,
  soundVolumes: {
    rain: 0.45,
    birds: 0.35,
    whitenoise: 0.25,
    bells: 0.35,
  },
  binauralFrequencyHz: 10,
  binauralVolume: 0.25,
};

let dbInstance: Database.Database | null = null;

export function getDb(): Database.Database {
  if (dbInstance) {
    return dbInstance;
  }

  if (!fs.existsSync(DB_DIR)) {
    fs.mkdirSync(DB_DIR, { recursive: true });
  }

  const db = new Database(DB_PATH);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');

  const initSql = fs.readFileSync(INIT_SQL_PATH, 'utf-8');
  db.exec(initSql);

  seedInitialRecords(db);

  dbInstance = db;
  return db;
}

function seedInitialRecords(db: Database.Database): void {
  const existingProfile = db
    .prepare('SELECT id FROM user_profiles ORDER BY id ASC LIMIT 1')
    .get() as { id: number } | undefined;

  let profileId = existingProfile?.id;

  if (!profileId) {
    const insertProfile = db.prepare(
      'INSERT INTO user_profiles (username, preferences) VALUES (?, ?)'
    );
    const result = insertProfile.run(
      'Scholar',
      JSON.stringify(DEFAULT_PREFERENCES)
    );
    profileId = Number(result.lastInsertRowid);
  }

  const existingPrefs = db
    .prepare('SELECT id FROM user_preferences WHERE profile_id = ?')
    .get(profileId);

  if (!existingPrefs) {
    db.prepare(
      `INSERT INTO user_preferences (
        profile_id,
        study_interval_minutes,
        preferred_meditation_minutes,
        breathing_chimes_enabled,
        sound_volumes,
        binaural_frequency_hz,
        binaural_volume
      ) VALUES (?, ?, ?, ?, ?, ?, ?)`
    ).run(
      profileId,
      DEFAULT_PREFERENCES.studyIntervalMinutes,
      DEFAULT_PREFERENCES.preferredMeditationMinutes,
      DEFAULT_PREFERENCES.breathingChimesEnabled ? 1 : 0,
      JSON.stringify(DEFAULT_PREFERENCES.soundVolumes),
      DEFAULT_PREFERENCES.binauralFrequencyHz,
      DEFAULT_PREFERENCES.binauralVolume
    );
  }

  // Seed starter anonymous campus notes once if table is empty
  const wallCountRow = db
    .prepare('SELECT COUNT(*) AS count FROM campus_calm_messages')
    .get() as { count: number };

  if (wallCountRow.count === 0) {
    const starterMessages = [
      {
        message: 'If you are reading this at 2 AM in the library, drink a glass of water and drop your shoulders. You have already learned more than you think.',
        topic: 'Late Night',
        support_count: 14,
      },
      {
        message: 'One tough paper does not erase an entire semester of honest effort. Breathe for 60 seconds before opening your exam booklet.',
        topic: 'Exam Day',
        support_count: 19,
      },
      {
        message: 'To whoever feels behind right now: slow, steady progress beats panic cramming every single time. We are all cheering quietly for you.',
        topic: 'Encouragement',
        support_count: 11,
      },
      {
        message: 'Rest is how your brain saves what you studied today. Close the tabs when you finish this chapter and let yourself sleep.',
        topic: 'Rest & Sleep',
        support_count: 9,
      },
    ];

    const insertNote = db.prepare(
      'INSERT INTO campus_calm_messages (message, topic, support_count) VALUES (?, ?, ?)'
    );
    for (const note of starterMessages) {
      insertNote.run(note.message, note.topic, note.support_count);
    }
  }
}
