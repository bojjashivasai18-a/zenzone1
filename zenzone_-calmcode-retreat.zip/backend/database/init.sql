PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS user_profiles (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  preferences TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS user_preferences (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  profile_id INTEGER NOT NULL UNIQUE,
  study_interval_minutes INTEGER NOT NULL DEFAULT 45,
  preferred_meditation_minutes INTEGER NOT NULL DEFAULT 5,
  breathing_chimes_enabled INTEGER NOT NULL DEFAULT 1,
  sound_volumes TEXT NOT NULL DEFAULT '{"rain":0.45,"birds":0.35,"whitenoise":0.25,"bells":0.35}',
  binaural_frequency_hz REAL NOT NULL DEFAULT 10,
  binaural_volume REAL NOT NULL DEFAULT 0.25,
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (profile_id) REFERENCES user_profiles(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS mood_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  stress_level INTEGER NOT NULL CHECK (stress_level BETWEEN 1 AND 5),
  mood_emoji TEXT NOT NULL,
  reflection TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS meditation_sessions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  duration INTEGER NOT NULL CHECK (duration > 0),
  completed INTEGER NOT NULL DEFAULT 1,
  session_date TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS campus_calm_messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  message TEXT NOT NULL,
  topic TEXT NOT NULL DEFAULT 'Encouragement',
  support_count INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS favorite_affirmations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  affirmation TEXT NOT NULL,
  situation TEXT NOT NULL,
  source TEXT NOT NULL DEFAULT 'local',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
