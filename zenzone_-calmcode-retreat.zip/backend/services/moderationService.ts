const ALLOWED_TOPICS = new Set([
  'Encouragement',
  'Exam Day',
  'Late Night',
  'Rest & Sleep',
  'Focus',
]);

const BLOCKED_TERMS = [
  'kill yourself',
  'kys',
  'self harm',
  'suicide',
  'fuck',
  'shit',
  'bitch',
  'asshole',
  'slur',
  'idiot',
  'worthless',
  'stupid',
  'loser',
];

export interface ModerationResult {
  valid: boolean;
  sanitizedMessage: string;
  sanitizedTopic: string;
  error?: string;
}

export function moderateCalmMessage(rawMessage: unknown, rawTopic: unknown): ModerationResult {
  if (typeof rawMessage !== 'string') {
    return {
      valid: false,
      sanitizedMessage: '',
      sanitizedTopic: 'Encouragement',
      error: 'Please enter a short encouraging message.',
    };
  }

  const trimmed = rawMessage.replace(/\s+/g, ' ').trim();

  if (trimmed.length < 8) {
    return {
      valid: false,
      sanitizedMessage: '',
      sanitizedTopic: 'Encouragement',
      error: 'Message must be at least 8 characters long.',
    };
  }

  if (trimmed.length > 240) {
    return {
      valid: false,
      sanitizedMessage: '',
      sanitizedTopic: 'Encouragement',
      error: 'Message must be 240 characters or fewer.',
    };
  }

  if (/https?:\/\/|www\./i.test(trimmed)) {
    return {
      valid: false,
      sanitizedMessage: '',
      sanitizedTopic: 'Encouragement',
      error: 'Links are not permitted on the Campus Calm Wall.',
    };
  }

  const lower = trimmed.toLowerCase();
  for (const term of BLOCKED_TERMS) {
    if (lower.includes(term)) {
      return {
        valid: false,
        sanitizedMessage: '',
        sanitizedTopic: 'Encouragement',
        error: 'Please keep messages supportive, kind, and free of harsh language.',
      };
    }
  }

  const topicStr = typeof rawTopic === 'string' && ALLOWED_TOPICS.has(rawTopic)
    ? rawTopic
    : 'Encouragement';

  return {
    valid: true,
    sanitizedMessage: trimmed,
    sanitizedTopic: topicStr,
  };
}
