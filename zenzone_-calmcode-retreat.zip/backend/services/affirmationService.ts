import { GoogleGenAI } from '@google/genai';
import type { AffirmationSituation } from '../../shared/types/zenzone.ts';

const LOCAL_AFFIRMATIONS: Record<AffirmationSituation, string[]> = {
  'before-exam': [
    'I have prepared honestly with the time I had, and I can meet each question calmly one line at a time.',
    'My memory works best when my breath is steady; I give myself permission to pause and read clearly.',
    'An examination asks what I know today, not for perfection. Calm focus unlocks what I have already studied.',
    'Walking into the room quietly and steadily is enough. I trust my preparation and my problem-solving pace.',
  ],
  'imposter-syndrome': [
    'Every student in this room is still learning. My curiosity, persistence, and questions prove that I belong here.',
    'Not knowing everything immediately is not a flaw—it is the exact reason university exists.',
    'I earned my place through real effort, even on the days I quietly doubted myself.',
    'Comparing my behind-the-scenes struggle to someone else’s calm exterior tells an incomplete story. I am growing at my own pace.',
  ],
  'late-night-fatigue': [
    'Rest is part of learning, not the opposite of it. Stepping back tonight helps my mind organize tomorrow’s clarity.',
    'I have done meaningful work today. Letting my shoulders drop and closing my notes is a wise academic decision.',
    'My worth is not measured by how late I stay awake; steady care sustains clear thinking.',
    'One gentle breath, a glass of water, and restorative sleep will serve me better than an extra hour of exhausted rereading.',
  ],
  'result-anxiety': [
    'One grade measures a single afternoon’s paper—never my intelligence, character, or long-term path.',
    'Whatever number arrives, I have the resilience to learn from it, adjust gently, and keep moving forward.',
    'Waiting feels uncertain, yet I can keep my hands steady and care for my present day while results unfold.',
    'My future is built across dozens of semesters, projects, and choices—not decided by one single test.',
  ],
  'general-confidence': [
    'I have navigated challenging deadlines before, and I carry that same quiet steadiness into today.',
    'Progress does not need to feel dramatic to be real; each focused 25-minute block builds genuine mastery.',
    'I can hold high standards for my work while speaking to myself with patience and warmth.',
    'My mind is clear when I slow down. I am capable of breaking large challenges into calm, manageable steps.',
  ],
};

const SITUATION_LABELS: Record<AffirmationSituation, string> = {
  'before-exam': 'moments before stepping into an examination',
  'imposter-syndrome': 'dealing with imposter syndrome and self-doubt in university',
  'late-night-fatigue': 'late-night study exhaustion and needing permission to rest',
  'result-anxiety': 'anxiously waiting for examination results',
  'general-confidence': 'building steady academic confidence during exam season',
};

function isGeminiConfigured(): boolean {
  const key = process.env.GEMINI_API_KEY?.trim();
  return Boolean(key && key !== 'MY_GEMINI_API_KEY' && key.length > 10);
}

export async function generateExamAffirmation(
  situation: AffirmationSituation,
  lastAffirmation?: string
): Promise<{ affirmation: string; situation: AffirmationSituation; source: 'gemini' | 'local' }> {
  if (isGeminiConfigured()) {
    try {
      const ai = new GoogleGenAI({
        apiKey: process.env.GEMINI_API_KEY,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      });

      const contextLabel = SITUATION_LABELS[situation] || SITUATION_LABELS['general-confidence'];
      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: `Write one grounded, warm, non-cliche exam affirmation (1 to 2 sentences, max 35 words) for a university student who is ${contextLabel}.${lastAffirmation ? ` Avoid repeating this phrasing: "${lastAffirmation}".` : ''}`,
        config: {
          systemInstruction:
            'You are a calm, practical Scandinavian student wellness companion. Respond only with the affirmation text in plain language—no quotes, no emojis, no markdown, and no medical claims.',
        },
      });

      const generated = response.text?.trim().replace(/^["']|["']$/g, '');
      if (generated && generated.length >= 12) {
        return {
          affirmation: generated,
          situation,
          source: 'gemini',
        };
      }
    } catch (error) {
      console.warn('Gemini affirmation fallback to deterministic local pool:', error);
    }
  }

  const pool = LOCAL_AFFIRMATIONS[situation] || LOCAL_AFFIRMATIONS['general-confidence'];
  const candidates = lastAffirmation ? pool.filter((item) => item !== lastAffirmation) : pool;
  const pickPool = candidates.length > 0 ? candidates : pool;
  const index = Math.floor(Math.random() * pickPool.length);

  return {
    affirmation: pickPool[index],
    situation,
    source: 'local',
  };
}

export function hasConfiguredAiKey(): boolean {
  return isGeminiConfigured();
}
