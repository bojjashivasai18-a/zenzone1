import type {
  AffirmationSituation,
  CampusCalmMessage,
  FavoriteAffirmation,
  MeditationSummary,
  MoodLog,
  ReflectionPrompt,
  UserPreferences,
  UserProfile,
  WeeklyStressPoint,
  YogaPose,
} from '../../shared/types/zenzone';

const PREFS_STORAGE_KEY = 'zenzone_user_preferences_v1';
const MOODS_BACKUP_KEY = 'zenzone_mood_logs_backup_v1';

export function savePreferencesLocal(prefs: UserPreferences): void {
  try {
    localStorage.setItem(PREFS_STORAGE_KEY, JSON.stringify(prefs));
  } catch {
    // Ignore storage quota errors
  }
}

export function loadPreferencesLocal(): UserPreferences | null {
  try {
    const raw = localStorage.getItem(PREFS_STORAGE_KEY);
    return raw ? (JSON.parse(raw) as UserPreferences) : null;
  } catch {
    return null;
  }
}

export function saveMoodLogsLocal(logs: MoodLog[]): void {
  try {
    localStorage.setItem(MOODS_BACKUP_KEY, JSON.stringify(logs));
  } catch {
    // Ignore
  }
}

async function requestJson<T>(url: string, options?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    headers: {
      'Content-Type': 'application/json',
      ...(options?.headers ?? {}),
    },
    ...options,
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error((data as { error?: string }).error || `Request failed (${res.status})`);
  }
  return data as T;
}

export const api = {
  async getProfile(): Promise<UserProfile> {
    return requestJson<UserProfile>('/api/profile');
  },

  async updateProfile(payload: {
    username?: string;
    preferences?: Partial<UserPreferences>;
  }): Promise<UserProfile> {
    const updated = await requestJson<UserProfile>('/api/profile', {
      method: 'PUT',
      body: JSON.stringify(payload),
    });
    if (updated.preferences) {
      savePreferencesLocal(updated.preferences);
    }
    return updated;
  },

  async getMoods(): Promise<{ logs: MoodLog[]; weeklyTrend: WeeklyStressPoint[] }> {
    const data = await requestJson<{ logs: MoodLog[]; weeklyTrend: WeeklyStressPoint[] }>('/api/moods');
    saveMoodLogsLocal(data.logs);
    return data;
  },

  async createMood(payload: {
    stress_level: number;
    mood_emoji: string;
    reflection: string;
    created_at?: string;
  }): Promise<{ entry: MoodLog; logs: MoodLog[]; weeklyTrend: WeeklyStressPoint[] }> {
    const data = await requestJson<{
      entry: MoodLog;
      logs: MoodLog[];
      weeklyTrend: WeeklyStressPoint[];
    }>('/api/moods', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    saveMoodLogsLocal(data.logs);
    return data;
  },

  async updateMood(
    id: number,
    payload: { stress_level: number; mood_emoji: string; reflection: string }
  ): Promise<{ logs: MoodLog[]; weeklyTrend: WeeklyStressPoint[] }> {
    const data = await requestJson<{ logs: MoodLog[]; weeklyTrend: WeeklyStressPoint[] }>(
      `/api/moods/${id}`,
      {
        method: 'PUT',
        body: JSON.stringify(payload),
      }
    );
    saveMoodLogsLocal(data.logs);
    return data;
  },

  async deleteMood(id: number): Promise<{ logs: MoodLog[]; weeklyTrend: WeeklyStressPoint[] }> {
    const data = await requestJson<{ logs: MoodLog[]; weeklyTrend: WeeklyStressPoint[] }>(
      `/api/moods/${id}`,
      { method: 'DELETE' }
    );
    saveMoodLogsLocal(data.logs);
    return data;
  },

  async getMeditations(): Promise<MeditationSummary> {
    return requestJson<MeditationSummary>('/api/meditations');
  },

  async logMeditation(payload: {
    duration: number;
    completed: boolean;
    session_date?: string;
  }): Promise<MeditationSummary> {
    return requestJson<MeditationSummary>('/api/meditations', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  async getAffirmations(): Promise<{ favorites: FavoriteAffirmation[]; aiConfigured: boolean }> {
    return requestJson<{ favorites: FavoriteAffirmation[]; aiConfigured: boolean }>('/api/affirmations');
  },

  async generateAffirmation(
    situation: AffirmationSituation,
    lastAffirmation?: string
  ): Promise<{ affirmation: string; situation: AffirmationSituation; source: 'gemini' | 'local' }> {
    return requestJson('/api/affirmations/generate', {
      method: 'POST',
      body: JSON.stringify({ situation, lastAffirmation }),
    });
  },

  async saveFavoriteAffirmation(payload: {
    affirmation: string;
    situation: AffirmationSituation;
    source: 'gemini' | 'local';
  }): Promise<{ favorites: FavoriteAffirmation[] }> {
    return requestJson<{ favorites: FavoriteAffirmation[] }>('/api/affirmations/favorites', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  async deleteFavoriteAffirmation(id: number): Promise<{ favorites: FavoriteAffirmation[] }> {
    return requestJson<{ favorites: FavoriteAffirmation[] }>(`/api/affirmations/favorites/${id}`, {
      method: 'DELETE',
    });
  },

  async getCalmWall(): Promise<{ messages: CampusCalmMessage[] }> {
    return requestJson<{ messages: CampusCalmMessage[] }>('/api/calm-wall');
  },

  async postCalmWall(payload: { message: string; topic: string }): Promise<{ entry: CampusCalmMessage }> {
    return requestJson<{ entry: CampusCalmMessage }>('/api/calm-wall', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  async supportCalmWallMessage(id: number): Promise<{ entry: CampusCalmMessage }> {
    return requestJson<{ entry: CampusCalmMessage }>(`/api/calm-wall/${id}/support`, {
      method: 'POST',
    });
  },

  async getYogaPoses(): Promise<{ poses: YogaPose[] }> {
    return requestJson<{ poses: YogaPose[] }>('/api/datasets/yoga');
  },

  async getReflectionPrompts(): Promise<{ prompts: ReflectionPrompt[] }> {
    return requestJson<{ prompts: ReflectionPrompt[] }>('/api/datasets/prompts');
  },
};
