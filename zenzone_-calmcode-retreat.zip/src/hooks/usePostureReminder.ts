import { useCallback, useEffect, useRef, useState } from 'react';

const STUDY_STORAGE_KEY = 'zenzone_study_elapsed_seconds';

export interface PostureReminderState {
  elapsedStudySeconds: number;
  intervalMinutes: number;
  isReminderOpen: boolean;
  isPausedBySession: boolean;
  resetStudyTimer: () => void;
  dismissReminder: () => void;
  triggerDemoReminder: () => void;
}

export function usePostureReminder(
  intervalMinutes = 45,
  suppressReminder = false
): PostureReminderState {
  const [elapsedStudySeconds, setElapsedStudySeconds] = useState<number>(() => {
    try {
      const saved = Number(localStorage.getItem(STUDY_STORAGE_KEY));
      return Number.isFinite(saved) && saved >= 0 ? saved : 0;
    } catch {
      return 0;
    }
  });
  const [isReminderOpen, setIsReminderOpen] = useState<boolean>(false);
  const pendingReminderRef = useRef<boolean>(false);

  const thresholdSeconds = Math.max(1, intervalMinutes) * 60;

  // Keep elapsed study time synced to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STUDY_STORAGE_KEY, String(elapsedStudySeconds));
    } catch {
      // Ignore storage errors
    }
  }, [elapsedStudySeconds]);

  // Trigger deferred reminder once active breathing/meditation/SOS session ends
  useEffect(() => {
    if (!suppressReminder && pendingReminderRef.current) {
      pendingReminderRef.current = false;
      setIsReminderOpen(true);
    }
  }, [suppressReminder]);

  useEffect(() => {
    const tick = () => {
      // Only count active continuous screen study time when tab is visible and no wellness session is running
      if (document.visibilityState !== 'visible' || suppressReminder || isReminderOpen) {
        return;
      }

      setElapsedStudySeconds((prev) => {
        const next = prev + 1;
        if (next >= thresholdSeconds) {
          if (suppressReminder) {
            pendingReminderRef.current = true;
          } else {
            setIsReminderOpen(true);
          }
          return thresholdSeconds;
        }
        return next;
      });
    };

    const intervalId = window.setInterval(tick, 1000);
    const handleVisibility = () => {
      if (
        document.visibilityState === 'visible' &&
        !suppressReminder &&
        pendingReminderRef.current
      ) {
        pendingReminderRef.current = false;
        setIsReminderOpen(true);
      }
    };

    document.addEventListener('visibilitychange', handleVisibility);
    return () => {
      window.clearInterval(intervalId);
      document.removeEventListener('visibilitychange', handleVisibility);
    };
  }, [thresholdSeconds, suppressReminder, isReminderOpen]);

  const resetStudyTimer = useCallback(() => {
    pendingReminderRef.current = false;
    setElapsedStudySeconds(0);
    setIsReminderOpen(false);
  }, []);

  const dismissReminder = useCallback(() => {
    pendingReminderRef.current = false;
    setElapsedStudySeconds(0);
    setIsReminderOpen(false);
  }, []);

  const triggerDemoReminder = useCallback(() => {
    if (suppressReminder) {
      pendingReminderRef.current = true;
      return;
    }
    setIsReminderOpen(true);
  }, [suppressReminder]);

  return {
    elapsedStudySeconds,
    intervalMinutes,
    isReminderOpen,
    isPausedBySession: suppressReminder,
    resetStudyTimer,
    dismissReminder,
    triggerDemoReminder,
  };
}
