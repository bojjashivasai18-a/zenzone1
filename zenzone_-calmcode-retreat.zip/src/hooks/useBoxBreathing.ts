import { useCallback, useEffect, useRef, useState } from 'react';
import { soundEngine } from '../audio/SoundEngine';
import type { BreathingPhase } from '../../shared/types/zenzone';

export type BreathingStatus = 'idle' | 'running' | 'paused';

const PHASE_DURATION_MS = 4000;
const CYCLE_DURATION_MS = PHASE_DURATION_MS * 4;

const PHASE_ORDER: BreathingPhase[] = ['inhale', 'hold-in', 'exhale', 'hold-out'];

export const PHASE_META: Record<
  BreathingPhase,
  { label: string; instruction: string; minScale: number; maxScale: number }
> = {
  inhale: {
    label: 'Inhale',
    instruction: 'Breathe in slowly through your nose',
    minScale: 0.72,
    maxScale: 1.0,
  },
  'hold-in': {
    label: 'Hold',
    instruction: 'Hold the breath gently without tension',
    minScale: 1.0,
    maxScale: 1.0,
  },
  exhale: {
    label: 'Exhale',
    instruction: 'Release steadily through parted lips',
    minScale: 1.0,
    maxScale: 0.72,
  },
  'hold-out': {
    label: 'Hold',
    instruction: 'Rest softly before the next breath',
    minScale: 0.72,
    maxScale: 0.72,
  },
};

export interface BoxBreathingState {
  status: BreathingStatus;
  phase: BreathingPhase;
  phaseLabel: string;
  phaseInstruction: string;
  phaseSecondsRemaining: number;
  phaseProgress: number;
  circleScale: number;
  cyclesCompleted: number;
  elapsedSeconds: number;
  chimesEnabled: boolean;
  setChimesEnabled: (enabled: boolean) => void;
  start: () => void;
  pause: () => void;
  resume: () => void;
  stop: () => void;
}

export function useBoxBreathing(initialChimes = true): BoxBreathingState {
  const [status, setStatus] = useState<BreathingStatus>('idle');
  const [chimesEnabled, setChimesEnabled] = useState<boolean>(initialChimes);
  const [phase, setPhase] = useState<BreathingPhase>('inhale');
  const [phaseSecondsRemaining, setPhaseSecondsRemaining] = useState<number>(4);
  const [phaseProgress, setPhaseProgress] = useState<number>(0);
  const [circleScale, setCircleScale] = useState<number>(0.72);
  const [cyclesCompleted, setCyclesCompleted] = useState<number>(0);
  const [elapsedSeconds, setElapsedSeconds] = useState<number>(0);

  const rafRef = useRef<number | null>(null);
  const accumulatedMsRef = useRef<number>(0);
  const lastFrameTimeRef = useRef<number | null>(null);
  const lastPhaseIndexRef = useRef<number>(-1);
  const chimesRef = useRef<boolean>(chimesEnabled);

  useEffect(() => {
    chimesRef.current = chimesEnabled;
  }, [chimesEnabled]);

  const computeFromElapsed = useCallback((totalMs: number) => {
    const cycleIndex = Math.floor(totalMs / CYCLE_DURATION_MS);
    const msInCycle = totalMs % CYCLE_DURATION_MS;
    const phaseIndex = Math.floor(msInCycle / PHASE_DURATION_MS);
    const msInPhase = msInCycle % PHASE_DURATION_MS;

    const currentPhase = PHASE_ORDER[phaseIndex];
    const progress = msInPhase / PHASE_DURATION_MS;
    const secondsLeft = Math.max(1, Math.ceil((PHASE_DURATION_MS - msInPhase) / 1000));

    // Smooth ease-in-out sine curve for organic circle expansion/contraction
    const eased = 0.5 - Math.cos(progress * Math.PI) / 2;
    const meta = PHASE_META[currentPhase];
    const scale = meta.minScale + (meta.maxScale - meta.minScale) * eased;

    if (lastPhaseIndexRef.current !== phaseIndex) {
      lastPhaseIndexRef.current = phaseIndex;
      if (chimesRef.current) {
        soundEngine.playBreathingChime(currentPhase);
      }
    }

    setPhase(currentPhase);
    setPhaseSecondsRemaining(secondsLeft);
    setPhaseProgress(progress);
    setCircleScale(scale);
    setCyclesCompleted(cycleIndex);
    setElapsedSeconds(Math.floor(totalMs / 1000));
  }, []);

  useEffect(() => {
    if (status !== 'running') {
      if (rafRef.current !== null) {
        cancelAnimationFrame(rafRef.current);
        rafRef.current = null;
      }
      lastFrameTimeRef.current = null;
      return;
    }

    const tick = (now: number) => {
      if (lastFrameTimeRef.current === null) {
        lastFrameTimeRef.current = now;
      }
      const delta = Math.min(250, now - lastFrameTimeRef.current);
      lastFrameTimeRef.current = now;
      accumulatedMsRef.current += delta;

      computeFromElapsed(accumulatedMsRef.current);
      rafRef.current = requestAnimationFrame(tick);
    };

    rafRef.current = requestAnimationFrame(tick);

    return () => {
      if (rafRef.current !== null) {
        cancelAnimationFrame(rafRef.current);
        rafRef.current = null;
      }
    };
  }, [status, computeFromElapsed]);

  const start = useCallback(() => {
    accumulatedMsRef.current = 0;
    lastFrameTimeRef.current = null;
    lastPhaseIndexRef.current = -1;
    computeFromElapsed(0);
    setStatus('running');
  }, [computeFromElapsed]);

  const pause = useCallback(() => {
    setStatus('paused');
  }, []);

  const resume = useCallback(() => {
    lastFrameTimeRef.current = null;
    setStatus('running');
  }, []);

  const stop = useCallback(() => {
    if (rafRef.current !== null) {
      cancelAnimationFrame(rafRef.current);
      rafRef.current = null;
    }
    accumulatedMsRef.current = 0;
    lastFrameTimeRef.current = null;
    lastPhaseIndexRef.current = -1;
    setStatus('idle');
    setPhase('inhale');
    setPhaseSecondsRemaining(4);
    setPhaseProgress(0);
    setCircleScale(0.72);
    setCyclesCompleted(0);
    setElapsedSeconds(0);
  }, []);

  const meta = PHASE_META[phase];

  return {
    status,
    phase,
    phaseLabel: meta.label,
    phaseInstruction: meta.instruction,
    phaseSecondsRemaining,
    phaseProgress,
    circleScale,
    cyclesCompleted,
    elapsedSeconds,
    chimesEnabled,
    setChimesEnabled,
    start,
    pause,
    resume,
    stop,
  };
}
