import { Clock, RotateCcw, Sparkles } from 'lucide-react';
import { useCallback, useEffect, useState } from 'react';
import type {
  AffirmationSituation,
  CampusCalmMessage,
  FavoriteAffirmation,
  MeditationSummary,
  MoodLog,
  ReflectionPrompt,
  SoundTrackId,
  UserProfile,
  WeeklyStressPoint,
  YogaPose,
} from '../shared/types/zenzone';
import { AffirmationGenerator } from './components/AffirmationGenerator';
import { AmbientSoundscape } from './components/AmbientSoundscape';
import { BinauralBeatsPlayer } from './components/BinauralBeatsPlayer';
import { BoxBreathingVisualizer } from './components/BoxBreathingVisualizer';
import { CampusCalmWall } from './components/CampusCalmWall';
import { ExamPanicSOSModal } from './components/ExamPanicSOSModal';
import { MeditationTimer } from './components/MeditationTimer';
import { MoodJournal } from './components/MoodJournal';
import { Navbar, type NavSectionId } from './components/Navbar';
import { PostureBreakOverlay } from './components/PostureBreakOverlay';
import { YogaGallery } from './components/YogaGallery';
import promptsFallback from './data/reflectionPrompts.json';
import yogaFallback from './data/yogaPoses.json';
import { usePostureReminder } from './hooks/usePostureReminder';
import { api, loadPreferencesLocal, savePreferencesLocal } from './services/api';

function formatStudyTimer(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

export default function App() {
  const [activeSection, setActiveSection] = useState<NavSectionId>('overview');
  const [sosOpen, setSosOpen] = useState<boolean>(false);

  // Active wellness session flags so the 45-min posture dimmer never interrupts
  const [breathingActive, setBreathingActive] = useState<boolean>(false);
  const [meditationActive, setMeditationActive] = useState<boolean>(false);

  // Application state backed by SQLite + LocalStorage
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [editingName, setEditingName] = useState<boolean>(false);
  const [nameInput, setNameInput] = useState<string>('Scholar');

  const [moodLogs, setMoodLogs] = useState<MoodLog[]>([]);
  const [weeklyTrend, setWeeklyTrend] = useState<WeeklyStressPoint[]>([]);
  const [moodsLoading, setMoodsLoading] = useState<boolean>(true);

  const [meditationSummary, setMeditationSummary] = useState<MeditationSummary>({
    sessions: [],
    currentStreak: 0,
    totalMinutes: 0,
    totalSessions: 0,
  });

  const [favoriteAffirmations, setFavoriteAffirmations] = useState<FavoriteAffirmation[]>([]);
  const [aiConfigured, setAiConfigured] = useState<boolean>(false);
  const [calmMessages, setCalmMessages] = useState<CampusCalmMessage[]>([]);

  const [yogaPoses, setYogaPoses] = useState<YogaPose[]>(yogaFallback as YogaPose[]);
  const [reflectionPrompts, setReflectionPrompts] = useState<ReflectionPrompt[]>(
    promptsFallback as ReflectionPrompt[]
  );

  const [toastMessage, setToastMessage] = useState<string>('');
  const [errorBanner, setErrorBanner] = useState<string>('');

  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
    window.setTimeout(() => {
      setToastMessage((curr) => (curr === msg ? '' : curr));
    }, 3500);
  }, []);

  const studyIntervalMinutes = profile?.preferences.studyIntervalMinutes ?? 45;
  const posture = usePostureReminder(
    studyIntervalMinutes,
    sosOpen || breathingActive || meditationActive
  );

  // Load initial data from Express + SQLite backend
  useEffect(() => {
    let mounted = true;

    async function loadAll() {
      try {
        const [
          profileRes,
          moodsRes,
          meditationsRes,
          affirmationsRes,
          calmRes,
          yogaRes,
          promptsRes,
        ] = await Promise.all([
          api.getProfile(),
          api.getMoods(),
          api.getMeditations(),
          api.getAffirmations(),
          api.getCalmWall(),
          api.getYogaPoses(),
          api.getReflectionPrompts(),
        ]);

        if (!mounted) return;
        setProfile(profileRes);
        setNameInput(profileRes.username);
        savePreferencesLocal(profileRes.preferences);

        setMoodLogs(moodsRes.logs);
        setWeeklyTrend(moodsRes.weeklyTrend);
        setMeditationSummary(meditationsRes);
        setFavoriteAffirmations(affirmationsRes.favorites);
        setAiConfigured(affirmationsRes.aiConfigured);
        setCalmMessages(calmRes.messages);
        if (yogaRes.poses?.length) setYogaPoses(yogaRes.poses);
        if (promptsRes.prompts?.length) setReflectionPrompts(promptsRes.prompts);
      } catch (err) {
        if (!mounted) return;
        const cached = loadPreferencesLocal();
        if (cached) {
          setProfile({
            id: 1,
            username: 'Scholar',
            created_at: new Date().toISOString(),
            preferences: cached,
          });
        }
        setErrorBanner(
          err instanceof Error
            ? `Unable to reach backend database: ${err.message}`
            : 'Unable to reach backend database.'
        );
      } finally {
        if (mounted) setMoodsLoading(false);
      }
    }

    void loadAll();
    return () => {
      mounted = false;
    };
  }, []);

  const handleSaveName = async (e: React.FormEvent) => {
    e.preventDefault();
    const clean = nameInput.trim();
    if (!clean) return;
    try {
      const updated = await api.updateProfile({ username: clean });
      setProfile(updated);
      setEditingName(false);
      showToast('Welcome name updated.');
    } catch {
      showToast('Could not update profile name.');
    }
  };

  const handleUpdatePreferences = async (
    partial: Partial<UserProfile['preferences']>
  ) => {
    try {
      const updated = await api.updateProfile({ preferences: partial });
      setProfile(updated);
    } catch {
      // Keep local experience smooth
    }
  };

  const handleSaveMood = async (payload: {
    stress_level: number;
    mood_emoji: string;
    reflection: string;
  }) => {
    const localIso = new Date(Date.now() - new Date().getTimezoneOffset() * 60000)
      .toISOString()
      .slice(0, 19);
    const res = await api.createMood({ ...payload, created_at: localIso });
    setMoodLogs(res.logs);
    setWeeklyTrend(res.weeklyTrend);
    showToast('Mood check-in saved to your journal.');
  };

  const handleUpdateMood = async (
    id: number,
    payload: { stress_level: number; mood_emoji: string; reflection: string }
  ) => {
    const res = await api.updateMood(id, payload);
    setMoodLogs(res.logs);
    setWeeklyTrend(res.weeklyTrend);
    showToast('Mood entry updated.');
  };

  const handleDeleteMood = async (id: number) => {
    const res = await api.deleteMood(id);
    setMoodLogs(res.logs);
    setWeeklyTrend(res.weeklyTrend);
    showToast('Mood entry removed.');
  };

  const handleCompleteSOS = async (payload: {
    stressBefore: number;
    stressAfter: number;
    reflection: string;
  }) => {
    const emoji =
      payload.stressAfter <= 2
        ? '😌'
        : payload.stressAfter === 3
        ? '🙂'
        : payload.stressAfter === 4
        ? '😟'
        : '😫';

    await handleSaveMood({
      stress_level: payload.stressAfter,
      mood_emoji: emoji,
      reflection: payload.reflection,
    });
  };

  const handleLogMeditation = async (durationSeconds: number) => {
    const localIso = new Date(Date.now() - new Date().getTimezoneOffset() * 60000)
      .toISOString()
      .slice(0, 19);
    const updated = await api.logMeditation({
      duration: durationSeconds,
      completed: true,
      session_date: localIso,
    });
    setMeditationSummary(updated);
    showToast('Meditation session logged.');
  };

  const handleGenerateAffirmation = async (
    situation: AffirmationSituation,
    lastAffirmation?: string
  ) => {
    return api.generateAffirmation(situation, lastAffirmation);
  };

  const handleSaveAffirmation = async (payload: {
    affirmation: string;
    situation: AffirmationSituation;
    source: 'gemini' | 'local';
  }) => {
    const res = await api.saveFavoriteAffirmation(payload);
    setFavoriteAffirmations(res.favorites);
    showToast('Affirmation saved to favorites.');
  };

  const handleDeleteAffirmation = async (id: number) => {
    const res = await api.deleteFavoriteAffirmation(id);
    setFavoriteAffirmations(res.favorites);
  };

  const handlePostCalmWall = async (payload: { message: string; topic: string }) => {
    const res = await api.postCalmWall(payload);
    setCalmMessages((prev) => [res.entry, ...prev]);
    showToast('Encouragement posted anonymously.');
  };

  const handleRefreshCalmWall = async () => {
    const res = await api.getCalmWall();
    setCalmMessages(res.messages);
  };

  const handleSupportCalmWall = async (id: number) => {
    const res = await api.supportCalmWallMessage(id);
    setCalmMessages((prev) => prev.map((m) => (m.id === id ? res.entry : m)));
  };

  const latestMood = moodLogs[0];
  const displayName = profile?.username || 'Scholar';

  const navigateAndScrollTop = (section: NavSectionId) => {
    setActiveSection(section);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-[#FAF8F5] text-[#242B27]">
      <Navbar
        activeSection={activeSection}
        onNavigate={navigateAndScrollTop}
        onOpenSOS={() => setSosOpen(true)}
      />

      {errorBanner && (
        <div
          role="alert"
          className="border-b border-[#E5CACA] bg-[#FBF2F2] px-4 py-2.5 text-center text-xs font-medium text-[#8C3D3D]"
        >
          {errorBanner}
        </div>
      )}

      {toastMessage && (
        <div
          role="status"
          className="fixed bottom-5 right-5 z-40 rounded-xl border border-[#C6D5CB] bg-white px-4 py-3 text-sm font-medium text-[#242B27] shadow-lg animate-zen-enter"
        >
          {toastMessage}
        </div>
      )}

      <main className="mx-auto max-w-[1200px] px-4 py-8 sm:px-6 sm:py-10">
        {activeSection === 'overview' && (
          <div className="space-y-12">
            {/* Hero Welcome Section */}
            <section className="overflow-hidden rounded-2xl border border-[#E5E0D8] bg-white">
              <div className="grid grid-cols-1 items-stretch lg:grid-cols-12">
                <div className="flex flex-col justify-between p-6 sm:p-10 lg:col-span-7">
                  <div>
                    <div className="flex flex-wrap items-center gap-2 text-xs text-[#5C6660]">
                      <span>CalmCode Retreat</span>
                      <span aria-hidden="true">·</span>
                      {editingName ? (
                        <form onSubmit={handleSaveName} className="inline-flex items-center gap-1.5">
                          <input
                            type="text"
                            maxLength={32}
                            value={nameInput}
                            onChange={(e) => setNameInput(e.target.value)}
                            aria-label="Your display name"
                            className="w-32 rounded-md border border-[#C6D5CB] bg-[#FAF8F5] px-2 py-0.5 text-xs text-[#242B27] focus:outline-none"
                          />
                          <button
                            type="submit"
                            className="font-medium text-[#557463] hover:underline cursor-pointer"
                          >
                            Save
                          </button>
                        </form>
                      ) : (
                        <button
                          type="button"
                          onClick={() => setEditingName(true)}
                          className="hover:text-[#242B27] hover:underline cursor-pointer"
                        >
                          Personalize name ({displayName})
                        </button>
                      )}
                    </div>

                    <h1 className="mt-3 font-display text-3xl font-medium leading-tight tracking-tight text-[#242B27] sm:text-4xl lg:text-5xl">
                      Welcome back, {displayName}. Take a gentle pause between study blocks.
                    </h1>

                    <p className="mt-4 max-w-xl text-base leading-relaxed text-[#5C6660]">
                      Short, evidence-inspired breathing resets, desk stretches, calm soundscapes, and private stress tracking—built for university exam weeks without clutter or subscriptions.
                    </p>
                  </div>

                  <div className="mt-8 flex flex-wrap items-center gap-3">
                    <button
                      type="button"
                      onClick={() => setSosOpen(true)}
                      className="inline-flex items-center gap-2 rounded-lg bg-[#6D5B7B] px-5 py-3 text-sm font-medium text-white transition-colors hover:bg-[#5B4B68] cursor-pointer"
                    >
                      <Sparkles className="h-4 w-4" />
                      <span>Exam Panic SOS</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => navigateAndScrollTop('breathe-meditate')}
                      className="rounded-lg border border-[#E5E0D8] bg-[#FAF8F5] px-5 py-3 text-sm font-medium text-[#242B27] transition-colors hover:bg-[#F3EFE8] cursor-pointer"
                    >
                      Start 4-4-4-4 Breathing
                    </button>
                  </div>
                </div>

                <div className="relative min-h-[240px] bg-[#E8F0EB] lg:col-span-5">
                  <img
                    src="/src/assets/images/zenzone_hero_sanctuary_1795673977015.jpg"
                    alt="Minimalist Scandinavian study desk beside sunlit misty pine trees"
                    referrerPolicy="no-referrer"
                    className="h-full w-full object-cover"
                  />
                </div>
              </div>

              {/* Daily Wellness Summary Strip */}
              <div className="grid grid-cols-1 divide-y divide-[#E5E0D8] border-t border-[#E5E0D8] bg-[#FAF8F5] sm:grid-cols-2 sm:divide-x sm:divide-y-0 lg:grid-cols-4">
                <div className="p-5">
                  <p className="text-xs text-[#5C6660]">Latest Stress Check-In</p>
                  <p className="mt-1 font-mono-tabular text-2xl font-medium text-[#242B27]">
                    {latestMood ? `${latestMood.stress_level}/5 ${latestMood.mood_emoji}` : 'Not logged'}
                  </p>
                </div>

                <div className="p-5">
                  <p className="text-xs text-[#5C6660]">Meditation Streak</p>
                  <p className="mt-1 font-mono-tabular text-2xl font-medium text-[#242B27]">
                    {meditationSummary.currentStreak}{' '}
                    <span className="text-sm font-normal text-[#5C6660]">
                      {meditationSummary.currentStreak === 1 ? 'day' : 'days'}
                    </span>
                  </p>
                </div>

                <div className="p-5">
                  <p className="text-xs text-[#5C6660]">Saved Affirmations</p>
                  <p className="mt-1 font-mono-tabular text-2xl font-medium text-[#242B27]">
                    {favoriteAffirmations.length}
                  </p>
                </div>

                <div className="flex items-center justify-between gap-3 p-5">
                  <div>
                    <p className="text-xs text-[#5C6660]">
                      Posture Timer ({studyIntervalMinutes}m)
                    </p>
                    <p className="mt-1 flex items-center gap-1.5 font-mono-tabular text-xl font-medium text-[#242B27]">
                      <Clock className="h-4 w-4 text-[#557463]" />
                      <span>{formatStudyTimer(posture.elapsedStudySeconds)}</span>
                    </p>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      title="Reset 45-minute study timer"
                      onClick={posture.resetStudyTimer}
                      aria-label="Reset study posture timer"
                      className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-[#E5E0D8] bg-white text-[#5C6660] hover:text-[#242B27] cursor-pointer"
                    >
                      <RotateCcw className="h-3.5 w-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={posture.triggerDemoReminder}
                      className="rounded-lg border border-[#E5E0D8] bg-white px-2.5 py-1.5 text-xs font-medium text-[#242B27] hover:bg-[#F3EFE8] cursor-pointer"
                    >
                      Break Cue
                    </button>
                  </div>
                </div>
              </div>
            </section>

            {/* Quick-Access Breathing + Meditation */}
            <section className="grid grid-cols-1 gap-6 lg:grid-cols-12">
              <div className="lg:col-span-6">
                <BoxBreathingVisualizer
                  compact
                  defaultChimes={profile?.preferences.breathingChimesEnabled ?? true}
                  onChimesChange={(enabled) =>
                    void handleUpdatePreferences({ breathingChimesEnabled: enabled })
                  }
                  onActiveChange={setBreathingActive}
                />
              </div>
              <div className="lg:col-span-6">
                <MeditationTimer
                  summary={meditationSummary}
                  defaultMinutes={profile?.preferences.preferredMeditationMinutes ?? 5}
                  onSessionCompleted={handleLogMeditation}
                  onActiveChange={setMeditationActive}
                />
              </div>
            </section>

            {/* Soundscape + Affirmations */}
            <section className="grid grid-cols-1 gap-6 lg:grid-cols-12">
              <div className="lg:col-span-7">
                <AmbientSoundscape
                  initialVolumes={profile?.preferences.soundVolumes}
                  onVolumesChange={(soundVolumes: Record<SoundTrackId, number>) =>
                    void handleUpdatePreferences({ soundVolumes })
                  }
                />
              </div>
              <div className="lg:col-span-5">
                <AffirmationGenerator
                  favorites={favoriteAffirmations}
                  aiConfigured={aiConfigured}
                  onGenerate={handleGenerateAffirmation}
                  onSaveFavorite={handleSaveAffirmation}
                  onDeleteFavorite={handleDeleteAffirmation}
                />
              </div>
            </section>

            {/* Mood Check-in & Weekly Progress Chart */}
            <section className="space-y-4">
              <div>
                <p className="text-xs font-medium text-[#5C6660]">Mood & Stress Journal</p>
                <h2 className="mt-1 font-display text-3xl font-medium text-[#242B27]">
                  Track Your Exam Week Rhythm
                </h2>
              </div>
              <MoodJournal
                logs={moodLogs}
                weeklyTrend={weeklyTrend}
                prompts={reflectionPrompts}
                onSaveEntry={handleSaveMood}
                onUpdateEntry={handleUpdateMood}
                onDeleteEntry={handleDeleteMood}
                loading={moodsLoading}
              />
            </section>

            {/* Yoga Gallery Preview */}
            <section className="space-y-4">
              <div>
                <p className="text-xs font-medium text-[#5C6660]">Micro-Yoga Reset</p>
                <h2 className="mt-1 font-display text-3xl font-medium text-[#242B27]">
                  Desk-Friendly Poses
                </h2>
              </div>
              <YogaGallery
                poses={yogaPoses}
                previewOnly
                onViewAll={() => navigateAndScrollTop('yoga')}
              />
            </section>

            {/* Campus Calm Wall Preview */}
            <section>
              <CampusCalmWall
                messages={calmMessages}
                previewOnly
                onPostMessage={handlePostCalmWall}
                onRefresh={handleRefreshCalmWall}
                onSupportMessage={handleSupportCalmWall}
                onViewAll={() => navigateAndScrollTop('calm-wall')}
              />
            </section>
          </div>
        )}

        {activeSection === 'breathe-meditate' && (
          <div className="space-y-8">
            <div>
              <p className="text-xs font-medium text-[#5C6660]">Breathwork, Sound & Stillness</p>
              <h1 className="mt-1 font-display text-3xl font-medium text-[#242B27] sm:text-4xl">
                Breathe, Listen, and Unwind
              </h1>
            </div>

            <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
              <div className="lg:col-span-6">
                <BoxBreathingVisualizer
                  defaultChimes={profile?.preferences.breathingChimesEnabled ?? true}
                  onChimesChange={(enabled) =>
                    void handleUpdatePreferences({ breathingChimesEnabled: enabled })
                  }
                  onActiveChange={setBreathingActive}
                />
              </div>
              <div className="lg:col-span-6">
                <MeditationTimer
                  summary={meditationSummary}
                  defaultMinutes={profile?.preferences.preferredMeditationMinutes ?? 5}
                  onSessionCompleted={handleLogMeditation}
                  onActiveChange={setMeditationActive}
                />
              </div>
            </div>

            <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
              <div className="lg:col-span-7">
                <AmbientSoundscape
                  initialVolumes={profile?.preferences.soundVolumes}
                  onVolumesChange={(soundVolumes) =>
                    void handleUpdatePreferences({ soundVolumes })
                  }
                />
              </div>
              <div className="lg:col-span-5">
                <BinauralBeatsPlayer
                  initialFrequency={profile?.preferences.binauralFrequencyHz ?? 10}
                  initialVolume={profile?.preferences.binauralVolume ?? 0.25}
                  onSettingsChange={(binauralFrequencyHz, binauralVolume) =>
                    void handleUpdatePreferences({ binauralFrequencyHz, binauralVolume })
                  }
                />
              </div>
            </div>
          </div>
        )}

        {activeSection === 'yoga' && (
          <div className="space-y-6">
            <div>
              <p className="text-xs font-medium text-[#5C6660]">Curated 10-Pose Gallery</p>
              <h1 className="mt-1 font-display text-3xl font-medium text-[#242B27] sm:text-4xl">
                Micro-Yoga for Study Desks
              </h1>
            </div>
            <YogaGallery poses={yogaPoses} />
          </div>
        )}

        {activeSection === 'journal' && (
          <div className="space-y-8">
            <div>
              <p className="text-xs font-medium text-[#5C6660]">Daily Reflection & Trends</p>
              <h1 className="mt-1 font-display text-3xl font-medium text-[#242B27] sm:text-4xl">
                Mood Journal & Exam Affirmations
              </h1>
            </div>

            <MoodJournal
              logs={moodLogs}
              weeklyTrend={weeklyTrend}
              prompts={reflectionPrompts}
              onSaveEntry={handleSaveMood}
              onUpdateEntry={handleUpdateMood}
              onDeleteEntry={handleDeleteMood}
              loading={moodsLoading}
            />

            <AffirmationGenerator
              favorites={favoriteAffirmations}
              aiConfigured={aiConfigured}
              onGenerate={handleGenerateAffirmation}
              onSaveFavorite={handleSaveAffirmation}
              onDeleteFavorite={handleDeleteAffirmation}
            />
          </div>
        )}

        {activeSection === 'calm-wall' && (
          <div className="space-y-6">
            <CampusCalmWall
              messages={calmMessages}
              onPostMessage={handlePostCalmWall}
              onRefresh={handleRefreshCalmWall}
              onSupportMessage={handleSupportCalmWall}
            />
          </div>
        )}
      </main>

      <footer className="mt-16 border-t border-[#E5E0D8] bg-[#F3EFE8]/60 py-8">
        <div className="mx-auto flex max-w-[1200px] flex-wrap items-center justify-between gap-4 px-4 text-xs text-[#5C6660] sm:px-6">
          <p>
            <strong className="font-medium text-[#242B27]">ZenZone: CalmCode Retreat</strong> — Student exam wellness companion.
          </p>
          <p>
            Designed for short study breaks. Not a substitute for professional healthcare or counseling services.
          </p>
        </div>
      </footer>

      <ExamPanicSOSModal
        isOpen={sosOpen}
        onClose={() => setSosOpen(false)}
        onCompleteAndSaveMood={handleCompleteSOS}
      />

      <PostureBreakOverlay
        isOpen={posture.isReminderOpen}
        elapsedMinutes={Math.max(1, Math.round(posture.elapsedStudySeconds / 60))}
        onDismiss={posture.dismissReminder}
        onTakeBreak={() => {
          posture.dismissReminder();
          navigateAndScrollTop('yoga');
        }}
      />
    </div>
  );
}
