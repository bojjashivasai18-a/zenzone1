import { Heart, RefreshCw, Send } from 'lucide-react';
import { useState } from 'react';
import type { CampusCalmMessage } from '../../shared/types/zenzone';

interface CampusCalmWallProps {
  messages: CampusCalmMessage[];
  previewOnly?: boolean;
  onPostMessage: (payload: { message: string; topic: string }) => Promise<void>;
  onRefresh: () => Promise<void>;
  onSupportMessage: (id: number) => Promise<void>;
  onViewAll?: () => void;
}

const TOPICS = ['Encouragement', 'Exam Day', 'Late Night', 'Rest & Sleep', 'Focus'];

function formatRelativeTime(isoDate: string): string {
  const date = new Date(isoDate.replace(' ', 'T') + (isoDate.includes('Z') ? '' : 'Z'));
  const diffMin = Math.max(1, Math.floor((Date.now() - date.getTime()) / 60000));
  if (diffMin < 60) return `${diffMin}m ago`;
  const diffHours = Math.floor(diffMin / 60);
  if (diffHours < 24) return `${diffHours}h ago`;
  const diffDays = Math.floor(diffHours / 24);
  return `${diffDays}d ago`;
}

export function CampusCalmWall({
  messages,
  previewOnly = false,
  onPostMessage,
  onRefresh,
  onSupportMessage,
  onViewAll,
}: CampusCalmWallProps) {
  const [messageText, setMessageText] = useState<string>('');
  const [topic, setTopic] = useState<string>('Encouragement');
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [refreshing, setRefreshing] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string>('');
  const [successMsg, setSuccessMsg] = useState<string>('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    const trimmed = messageText.trim();
    if (trimmed.length < 8) {
      setErrorMsg('Please write at least 8 characters of encouragement.');
      return;
    }

    setSubmitting(true);
    try {
      await onPostMessage({ message: trimmed, topic });
      setMessageText('');
      setSuccessMsg('Posted anonymously to the Campus Calm Wall.');
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Unable to post note.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    try {
      await onRefresh();
    } finally {
      setRefreshing(false);
    }
  };

  const visibleMessages = previewOnly ? messages.slice(0, 3) : messages;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-[#5C6660]">Anonymous Peer Encouragement</p>
          <h3 className="mt-1 font-display text-2xl font-medium text-[#242B27]">
            Campus Calm Wall
          </h3>
          <p className="mt-1 text-sm text-[#5C6660]">
            Leave a kind note for fellow students studying tonight. No names or accounts are displayed.
          </p>
        </div>

        <button
          type="button"
          onClick={() => void handleRefresh()}
          disabled={refreshing}
          className="inline-flex items-center gap-2 rounded-lg border border-[#E5E0D8] bg-white px-3.5 py-2 text-xs font-medium text-[#242B27] hover:bg-[#F3EFE8] cursor-pointer"
        >
          <RefreshCw className={`h-3.5 w-3.5 ${refreshing ? 'animate-spin' : ''}`} />
          <span>Refresh Wall</span>
        </button>
      </div>

      {!previewOnly && (
        <form
          onSubmit={handleSubmit}
          className="rounded-2xl border border-[#E5E0D8] bg-white p-6"
        >
          <div className="flex flex-wrap items-center justify-between gap-3">
            <label htmlFor="calm-wall-input" className="text-sm font-medium text-[#242B27]">
              Share an anonymous note
            </label>
            <div className="flex flex-wrap gap-1.5">
              {TOPICS.map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setTopic(t)}
                  className={`rounded-md px-2.5 py-1 text-xs font-medium transition-colors cursor-pointer ${
                    topic === t
                      ? 'bg-[#E8F0EB] text-[#242B27]'
                      : 'bg-[#FAF8F5] text-[#5C6660] hover:bg-[#F3EFE8]'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          <textarea
            id="calm-wall-input"
            rows={3}
            maxLength={240}
            value={messageText}
            onChange={(e) => setMessageText(e.target.value)}
            placeholder="Example: Take three slow breaths before turning the page—you know more than the panic says..."
            className="mt-3 w-full rounded-xl border border-[#E5E0D8] bg-[#FAF8F5] p-3 text-sm text-[#242B27] placeholder:text-[#8E9691] focus:border-[#557463] focus:bg-white focus:outline-none"
          />

          <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
            <div className="text-xs">
              {errorMsg ? (
                <span className="font-medium text-[#9A4242]">{errorMsg}</span>
              ) : successMsg ? (
                <span className="font-medium text-[#557463]">{successMsg}</span>
              ) : (
                <span className="text-[#5C6660]">
                  <span className="font-mono-tabular">{messageText.length}</span>/240 characters · Automated kindness filter active
                </span>
              )}
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="inline-flex items-center gap-2 rounded-lg bg-[#557463] px-4 py-2 text-xs font-medium text-white transition-colors hover:bg-[#466152] disabled:opacity-60 cursor-pointer"
            >
              <Send className="h-3.5 w-3.5" />
              <span>{submitting ? 'Posting...' : 'Post Anonymously'}</span>
            </button>
          </div>
        </form>
      )}

      {visibleMessages.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-[#D8D1C5] bg-white p-8 text-center">
          <p className="text-sm font-medium text-[#242B27]">No notes posted yet</p>
          <p className="mt-1 text-xs text-[#5C6660]">
            Be the first student to leave a calm note of encouragement.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
          {visibleMessages.map((item) => (
            <article
              key={item.id}
              className="flex flex-col justify-between rounded-2xl border border-[#E5E0D8] bg-white p-5"
            >
              <div>
                <div className="flex items-center gap-2 text-xs text-[#5C6660]">
                  <span className="font-medium text-[#557463]">{item.topic}</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono-tabular">{formatRelativeTime(item.created_at)}</span>
                </div>
                <p className="mt-3 text-sm leading-relaxed text-[#242B27]">“{item.message}”</p>
              </div>

              <div className="mt-4 flex items-center justify-between border-t border-[#E5E0D8] pt-3">
                <span className="text-xs text-[#5C6660]">Anonymous Student</span>
                <button
                  type="button"
                  onClick={() => void onSupportMessage(item.id)}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-[#E5E0D8] bg-[#FAF8F5] px-2.5 py-1 text-xs font-medium text-[#242B27] transition-colors hover:border-[#C6D5CB] hover:bg-[#E8F0EB] cursor-pointer"
                >
                  <Heart className="h-3.5 w-3.5 text-[#74688F]" />
                  <span className="font-mono-tabular">{item.support_count}</span>
                </button>
              </div>
            </article>
          ))}
        </div>
      )}

      {previewOnly && onViewAll && (
        <div className="flex justify-end">
          <button
            type="button"
            onClick={onViewAll}
            className="rounded-lg border border-[#E5E0D8] bg-white px-4 py-2 text-sm font-medium text-[#242B27] hover:bg-[#F3EFE8] cursor-pointer"
          >
            Open Full Campus Calm Wall
          </button>
        </div>
      )}
    </div>
  );
}
