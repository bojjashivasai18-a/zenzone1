import type { YogaPose } from '../../shared/types/zenzone';

interface YogaPoseIllustrationProps {
  illustrationKey: YogaPose['illustrationKey'];
  className?: string;
}

export function YogaPoseIllustration({
  illustrationKey,
  className = 'h-28 w-28',
}: YogaPoseIllustrationProps) {
  const strokeMain = '#3F594B';
  const strokeAccent = '#74688F';
  const fillSoft = '#E8F0EB';

  return (
    <svg
      viewBox="0 0 120 120"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
    >
      <circle cx="60" cy="60" r="52" fill={fillSoft} />

      {illustrationKey === 'neck-stretch' && (
        <g stroke={strokeMain} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="64" cy="38" r="10" />
          <path d="M58 48c-2 10-2 22-2 32" />
          <path d="M40 78h40" />
          <path d="M58 56c-8 2-14 8-14 18" />
          <path d="M62 56c8 2 14 8 14 18" />
          <path d="M48 34c-6 2-8 7-6 12" stroke={strokeAccent} strokeDasharray="3 3" />
        </g>
      )}

      {illustrationKey === 'spinal-twist' && (
        <g stroke={strokeMain} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="60" cy="34" r="9" />
          <path d="M60 43v30" />
          <path d="M44 74h32v18" />
          <path d="M60 54l16 8-6 12" />
          <path d="M60 54l-14 10 8 10" />
          <path d="M44 48c8-4 24-4 32 0" stroke={strokeAccent} strokeDasharray="3 3" />
        </g>
      )}

      {illustrationKey === 'shoulder-rolls' && (
        <g stroke={strokeMain} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="60" cy="36" r="9" />
          <path d="M60 45v32" />
          <path d="M42 58c6-5 30-5 36 0" />
          <path d="M42 58v20M78 58v20" />
          <path d="M36 52a7 7 0 1 1 8 8" stroke={strokeAccent} />
          <path d="M84 52a7 7 0 1 0-8 8" stroke={strokeAccent} />
        </g>
      )}

      {illustrationKey === 'wrist-stretch' && (
        <g stroke={strokeMain} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
          <path d="M26 66h46l8-16" />
          <path d="M72 66l12-10" />
          <path d="M50 82l18-16" />
          <circle cx="76" cy="44" r="4" fill="#EFEBF6" stroke={strokeAccent} />
          <path d="M64 46c6-6 14-6 20 0" stroke={strokeAccent} strokeDasharray="3 3" />
        </g>
      )}

      {illustrationKey === 'forward-bend' && (
        <g stroke={strokeMain} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
          <path d="M38 74h28v18" />
          <path d="M40 74c4-18 18-24 32-12" />
          <circle cx="78" cy="68" r="8" />
          <path d="M72 72l-4 18" />
          <path d="M56 50c10-4 22 0 26 8" stroke={strokeAccent} strokeDasharray="3 3" />
        </g>
      )}

      {illustrationKey === 'eye-relaxation' && (
        <g stroke={strokeMain} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="60" cy="54" r="18" />
          <path d="M48 52c3 3 7 3 10 0" />
          <path d="M62 52c3 3 7 3 10 0" />
          <path d="M42 74c0-10 8-16 14-18" stroke={strokeAccent} />
          <path d="M78 74c0-10-8-16-14-18" stroke={strokeAccent} />
          <path d="M54 64c4 2 8 2 12 0" />
        </g>
      )}

      {illustrationKey === 'side-stretch' && (
        <g stroke={strokeMain} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="56" cy="36" r="8.5" />
          <path d="M58 45c-4 12-2 24 2 34" />
          <path d="M42 79h36" />
          <path d="M56 50c8-12 20-16 26-10" />
          <path d="M56 56l-12 18" />
          <path d="M68 42c6 6 8 16 6 24" stroke={strokeAccent} strokeDasharray="3 3" />
        </g>
      )}

      {illustrationKey === 'upper-back-stretch' && (
        <g stroke={strokeMain} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="68" cy="38" r="8.5" />
          <path d="M54 48c-8 8-8 22 0 32" />
          <path d="M40 80h36" />
          <path d="M56 54l26 4" />
          <circle cx="84" cy="58" r="3.5" fill="#EFEBF6" stroke={strokeAccent} />
          <path d="M44 52c-4 6-4 14 0 20" stroke={strokeAccent} strokeDasharray="3 3" />
        </g>
      )}

      {illustrationKey === 'seated-cat-cow' && (
        <g stroke={strokeMain} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="62" cy="35" r="8.5" />
          <path d="M60 44c-10 10-10 22 0 34" />
          <path d="M62 44c10 10 10 22 0 34" stroke={strokeAccent} strokeDasharray="3 3" />
          <path d="M44 78h34" />
          <path d="M58 56l14 14" />
        </g>
      )}

      {illustrationKey === 'ankle-rotations' && (
        <g stroke={strokeMain} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
          <path d="M36 44v34h26" />
          <path d="M62 78l16-8" />
          <path d="M78 70l8 4" />
          <circle cx="78" cy="70" r="12" stroke={strokeAccent} strokeDasharray="3 3" />
          <path d="M84 58l4 4-5 2" stroke={strokeAccent} />
        </g>
      )}
    </svg>
  );
}
