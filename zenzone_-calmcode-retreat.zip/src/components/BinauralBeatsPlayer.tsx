import { Headphones, Pause, Play, Square } from 'lucide-react';
import { useEffect, useState } from 'react';
import { soundEngine } from '../audio/SoundEngine';

interface BinauralBeatsPlayerProps {
  initialFrequency?: number;
  initialVolume?: number;
  onSettingsChange?: (frequencyHz: number, volume: number) => void;
}

const ALPHA_FREQUENCIES = [
  { hz: 8, label: '8 Hz · Deep Calm' },
  { hz: 9, label: '9 Hz · Soft Focus' },
  { hz: 10, label: '10 Hz · Relaxed Alpha' },
  { hz: 11, label: '11 Hz · Alert Calm' },
  { hz: 12, label: '12 Hz · Steady Study' },
];

export function BinauralBeatsPlayer({
  initialFrequency = 10,
  initialVolume = 0.25,
  onSettingsChange,
}: BinauralBeatsPlayerProps) {
  const [frequency, setFrequency] = useState<number>(initialFrequency);
  const [volume, setVolume] = useState<number>(initialVolume);
  const [isPlaying, setIsPlaying] = useState<boolean>(() => soundEngine.isBinauralPlaying());

  useEffect(() => {
    return () => {
      // Cleanly stop binaural oscillators if component unmounts
      soundEngine.stopBinaural();
    };
  }, []);

  const handleTogglePlay = () => {
    if (isPlaying) {
      soundEngine.stopBinaural();
      setIsPlaying(false);
    } else {
      const ok = soundEngine.startBinaural(frequency, volume);
      setIsPlaying(ok);
    }
  };

  const handleStop = () => {
    soundEngine.stopBinaural();
    setIsPlaying(false);
  };

  const handleFrequencySelect = (hz: number) => {
    setFrequency(hz);
    soundEngine.setBinauralFrequency(hz);
    onSettingsChange?.(hz, volume);
  };

  const handleVolumeChange = (nextPct: number) => {
    const nextVol = nextPct / 100;
    setVolume(nextVol);
    soundEngine.setBinauralVolume(nextVol);
    onSettingsChange?.(frequency, nextVol);
  };

  return (
    <div className="rounded-2xl border border-[#E5E0D8] bg-white p-6 sm:p-8">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-[#5C6660]">Alpha Range (8 Hz – 12 Hz)</p>
          <h3 className="mt-1 font-display text-2xl font-medium text-[#242B27]">
            Binaural Beats Player
          </h3>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleTogglePlay}
            className={`inline-flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-medium text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-[#74688F] ${
              isPlaying ? 'bg-[#74688F] hover:bg-[#61567B]' : 'bg-[#5A7B8C] hover:bg-[#496777]'
            }`}
          >
            {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
            <span>{isPlaying ? 'Pause' : 'Play Alpha'}</span>
          </button>

          {isPlaying && (
            <button
              type="button"
              onClick={handleStop}
              aria-label="Stop binaural beats"
              className="inline-flex items-center gap-1.5 rounded-lg border border-[#E5E0D8] bg-[#FAF8F5] px-3 py-2 text-sm font-medium text-[#242B27] hover:bg-[#F3EFE8] cursor-pointer"
            >
              <Square className="h-3.5 w-3.5" />
              <span>Stop</span>
            </button>
          )}
        </div>
      </div>

      <div className="mt-4 flex items-start gap-3 rounded-xl border border-[#E5E0D8] bg-[#FAF8F5] p-3.5 text-xs text-[#5C6660]">
        <Headphones className="mt-0.5 h-4 w-4 shrink-0 text-[#74688F]" />
        <p>
          <strong className="font-semibold text-[#242B27]">Headphones required:</strong> Left ear receives a 200 Hz tone and right ear receives{' '}
          <span className="font-mono-tabular font-medium text-[#242B27]">{200 + frequency} Hz</span> for stereo separation.
        </p>
      </div>

      <div className="mt-5">
        <p className="text-xs font-medium text-[#5C6660]">Select Alpha Frequency</p>
        <div className="mt-2 grid grid-cols-2 gap-2 sm:grid-cols-5">
          {ALPHA_FREQUENCIES.map((item) => {
            const active = frequency === item.hz;
            return (
              <button
                key={item.hz}
                type="button"
                onClick={() => handleFrequencySelect(item.hz)}
                className={`rounded-lg border px-3 py-2 text-left transition-colors cursor-pointer focus-visible:outline-2 focus-visible:outline-[#74688F] ${
                  active
                    ? 'border-[#74688F] bg-[#EFEBF6] text-[#242B27]'
                    : 'border-[#E5E0D8] bg-[#FAF8F5] text-[#5C6660] hover:bg-[#F3EFE8]'
                }`}
              >
                <div className="font-mono-tabular text-sm font-semibold text-[#242B27]">{item.hz} Hz</div>
                <div className="truncate text-[11px] text-[#5C6660]">{item.label.split('· ')[1]}</div>
              </button>
            );
          })}
        </div>
      </div>

      <div className="mt-5 flex items-center gap-3">
        <label htmlFor="binaural-volume" className="text-xs font-medium text-[#5C6660] shrink-0">
          Volume
        </label>
        <input
          id="binaural-volume"
          type="range"
          min={0}
          max={100}
          value={Math.round(volume * 100)}
          onChange={(e) => handleVolumeChange(Number(e.target.value))}
          className="h-1.5 w-full cursor-pointer accent-[#74688F]"
        />
        <span className="w-10 text-right font-mono-tabular text-xs text-[#242B27]">
          {Math.round(volume * 100)}%
        </span>
      </div>

      <p className="mt-4 text-xs text-[#5C6660]">
        Optional relaxation audio only. Binaural beats are not a medical device and do not guarantee cognitive or clinical outcomes.
      </p>
    </div>
  );
}
