import { Pause, Play, RotateCcw, Volume2, VolumeX } from 'lucide-react';
import { useEffect } from 'react';
import { useBoxBreathing } from '../hooks/useBoxBreathing';

interface BoxBreathingVisualizerProps {
  compact?: boolean;
  onActiveChange?: (isActive: boolean) => void;
  defaultChimes?: boolean;
  onChimesChange?: (enabled: boolean) => void;
}

function formatSeconds(totalSeconds: number): string {
  const mins = Math.floor(totalSeconds / 60);
  const secs = totalSeconds % 60;
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

export function BoxBreathingVisualizer({
  compact = false,
  onActiveChange,
  defaultChimes = true,
  onChimesChange,
}: BoxBreathingVisualizerProps) {
  const {
    status,
    phase,
    phaseLabel,
    phaseInstruction,
    phaseSecondsRemaining,
    circleScale,
    cyclesCompleted,
    elapsedSeconds,
    chimesEnabled,
    setChimesEnabled,
    start,
    pause,
    resume,
    stop,
  } = useBoxBreathing(defaultChimes);

  useEffect(() => {
    onActiveChange?.(status === 'running');
  }, [status, onActiveChange]);

  const toggleChimes = () => {
    const next = !chimesEnabled;
    setChimesEnabled(next);
    onChimesChange?.(next);
  };

  const phasePalette: Record<string, { ring: string; fill: string }> = {
    inhale: { ring: '#557463', fill: '#E8F0EB' },
    'hold-in': { ring: '#5A7B8C', fill: '#E8F0F4' },
    exhale: { ring: '#74688F', fill: '#EFEBF6' },
    'hold-out': { ring: '#8C857B', fill: '#F3EFE8' },
  };

  const colors = phasePalette[phase];

  return (
    <div className="rounded-2xl border border-[#E5E0D8] bg-white p-6 sm:p-8">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-[#5C6660]">4-4-4-4 Box Breathing</p>
          <h3 className="mt-1 font-display text-2xl font-medium text-[#242B27]">
            Synchronized Breath Pacer
          </h3>
        </div>

        <button
          type="button"
          onClick={toggleChimes}
          aria-pressed={chimesEnabled}
          className="inline-flex items-center gap-2 rounded-lg border border-[#E5E0D8] bg-[#FAF8F5] px-3 py-2 text-xs font-medium text-[#242B27] transition-colors hover:bg-[#F3EFE8] whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-[#557463]"
        >
          {chimesEnabled ? <Volume2 className="h-4 w-4 text-[#557463]" /> : <VolumeX className="h-4 w-4 text-[#5C6660]" />}
          <span>{chimesEnabled ? 'Chimes On' : 'Chimes Muted'}</span>
        </button>
      </div>

      <div className={`mt-6 flex flex-col items-center ${compact ? 'py-2' : 'py-6'}`}>
        {/* Unified synchronized visual ring */}
        <div className="relative flex h-56 w-56 items-center justify-center sm:h-64 sm:w-64">
          <div
            aria-hidden="true"
            className="absolute inset-0 rounded-full border border-[#E5E0D8]"
          />
          <div
            aria-hidden="true"
            className="absolute inset-4 rounded-full border border-dashed border-[#D8D1C5]"
          />

          <div
            style={{
              transform: `scale(${circleScale})`,
              backgroundColor: colors.fill,
              borderColor: colors.ring,
            }}
            className="flex h-44 w-44 flex-col items-center justify-center rounded-full border-2 will-change-transform sm:h-48 sm:w-48"
          >
            <span className="text-xs font-medium text-[#5C6660]">{phaseLabel}</span>
            <span className="mt-1 font-mono-tabular text-4xl font-medium text-[#242B27] sm:text-5xl">
              {status === 'idle' ? '4' : phaseSecondsRemaining}
            </span>
            <span className="mt-1 text-xs text-[#5C6660]">seconds</span>
          </div>
        </div>

        <p className="mt-4 max-w-sm text-center text-sm text-[#5C6660]">
          {status === 'idle'
            ? 'Press Start to begin 4s inhale, 4s hold, 4s exhale, 4s hold.'
            : phaseInstruction}
        </p>

        {/* Session telemetry row */}
        <div className="mt-5 flex items-center gap-6 text-sm text-[#5C6660]">
          <div>
            <span>Cycles </span>
            <span className="font-mono-tabular font-semibold text-[#242B27]">{cyclesCompleted}</span>
          </div>
          <span aria-hidden="true">·</span>
          <div>
            <span>Duration </span>
            <span className="font-mono-tabular font-semibold text-[#242B27]">
              {formatSeconds(elapsedSeconds)}
            </span>
          </div>
        </div>

        {/* Phase step indicators */}
        <div className="mt-5 grid w-full max-w-md grid-cols-4 gap-2 text-center text-xs">
          {(
            [
              { key: 'inhale', label: 'Inhale 4s' },
              { key: 'hold-in', label: 'Hold 4s' },
              { key: 'exhale', label: 'Exhale 4s' },
              { key: 'hold-out', label: 'Hold 4s' },
            ] as const
          ).map((step) => {
            const active = status !== 'idle' && phase === step.key;
            return (
              <div
                key={step.key}
                className={`rounded-lg border px-2 py-1.5 font-medium transition-colors ${
                  active
                    ? 'border-[#557463] bg-[#E8F0EB] text-[#242B27]'
                    : 'border-[#E5E0D8] bg-[#FAF8F5] text-[#5C6660]'
                }`}
              >
                {step.label}
              </div>
            );
          })}
        </div>

        {/* Controls */}
        <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
          {status === 'idle' && (
            <button
              type="button"
              onClick={start}
              className="inline-flex items-center gap-2 rounded-lg bg-[#557463] px-5 py-2.5 text-sm font-medium text-white transition-colors hover:bg-[#466152] whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-[#557463]"
            >
              <Play className="h-4 w-4" />
              <span>Start Breathing</span>
            </button>
          )}

          {status === 'running' && (
            <button
              type="button"
              onClick={pause}
              className="inline-flex items-center gap-2 rounded-lg bg-[#5A7B8C] px-5 py-2.5 text-sm font-medium text-white transition-colors hover:bg-[#496777] whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-[#5A7B8C]"
            >
              <Pause className="h-4 w-4" />
              <span>Pause</span>
            </button>
          )}

          {status === 'paused' && (
            <button
              type="button"
              onClick={resume}
              className="inline-flex items-center gap-2 rounded-lg bg-[#557463] px-5 py-2.5 text-sm font-medium text-white transition-colors hover:bg-[#466152] whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-[#557463]"
            >
              <Play className="h-4 w-4" />
              <span>Resume</span>
            </button>
          )}

          {status !== 'idle' && (
            <button
              type="button"
              onClick={stop}
              className="inline-flex items-center gap-2 rounded-lg border border-[#E5E0D8] bg-[#FAF8F5] px-4 py-2.5 text-sm font-medium text-[#242B27] transition-colors hover:bg-[#F3EFE8] whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-[#557463]"
            >
              <RotateCcw className="h-4 w-4" />
              <span>Stop</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
