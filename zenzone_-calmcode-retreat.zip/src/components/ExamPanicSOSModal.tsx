import { CloudRain, Volume2, VolumeX, X } from 'lucide-react';
import { useEffect, useState } from 'react';
import { soundEngine } from '../audio/SoundEngine';
import { useBoxBreathing } from '../hooks/useBoxBreathing';

interface ExamPanicSOSModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCompleteAndSaveMood: (payload: {
    stressBefore: number;
    stressAfter: number;
    reflection: string;
  }) => Promise<void>;
}

const GROUNDING_STEPS = [
  {
    title: '1. Drop your shoulders & unclench your jaw',
    message: 'You are safe in this moment. Let your hands rest heavily on your desk or lap.',
  },
  {
    title: '2. Follow the calm breathing square',
    message: 'Inhale for 4, hold gently for 4, exhale for 4, rest for 4. Your heart rate follows your exhale.',
  },
  {
    title: '3. Notice five quiet things in the room',
    message: 'Look away from your notes or screen. Spot a steady surface, natural light, or the floor beneath your feet.',
  },
  {
    title: '4. One question, one minute at a time',
    message: 'You do not have to solve the entire exam right now—only soften your breath for this next minute.',
  },
];

function formatClock(totalSeconds: number): string {
  const mins = Math.floor(totalSeconds / 60);
  const secs = totalSeconds % 60;
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

export function ExamPanicSOSModal({
  isOpen,
  onClose,
  onCompleteAndSaveMood,
}: ExamPanicSOSModalProps) {
  const [stage, setStage] = useState<'active' | 'rate-after' | 'saved'>('active');
  const [routineTotalSec, setRoutineTotalSec] = useState<number>(120);
  const [countdownSec, setCountdownSec] = useState<number>(120);
  const [stressBefore, setStressBefore] = useState<number>(5);
  const [stressAfter, setStressAfter] = useState<number>(2);
  const [rainEnabled, setRainEnabled] = useState<boolean>(true);
  const [saving, setSaving] = useState<boolean>(false);
  const [saveError, setSaveError] = useState<string>('');

  const breathing = useBoxBreathing(true);

  // Start guided breathing and gentle rain when SOS opens via user click
  useEffect(() => {
    if (!isOpen) return;

    setStage('active');
    setRoutineTotalSec(120);
    setCountdownSec(120);
    setStressBefore(5);
    setStressAfter(2);
    setSaveError('');
    setRainEnabled(true);

    breathing.start();
    soundEngine.startTrack('rain', 0.42);

    return () => {
      breathing.stop();
      soundEngine.stopTrack('rain');
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOpen]);

  // SOS Countdown timer
  useEffect(() => {
    if (!isOpen || stage !== 'active') return;

    const id = window.setInterval(() => {
      setCountdownSec((prev) => {
        if (prev <= 1) {
          window.clearInterval(id);
          breathing.stop();
          setStage('rate-after');
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => window.clearInterval(id);
  }, [isOpen, stage, breathing]);

  if (!isOpen) return null;

  const handleToggleRain = () => {
    if (rainEnabled) {
      soundEngine.stopTrack('rain');
      setRainEnabled(false);
    } else {
      soundEngine.startTrack('rain', 0.42);
      setRainEnabled(true);
    }
  };

  const handleSwitchDuration = (seconds: number) => {
    setRoutineTotalSec(seconds);
    setCountdownSec(seconds);
  };

  const handleFinishEarly = () => {
    breathing.stop();
    setStage('rate-after');
  };

  const handleSaveSession = async () => {
    setSaving(true);
    setSaveError('');
    try {
      await onCompleteAndSaveMood({
        stressBefore,
        stressAfter,
        reflection: `Completed Exam Panic SOS calming routine (${routineTotalSec}s). Stress shifted from ${stressBefore}/5 to ${stressAfter}/5.`,
      });
      setStage('saved');
    } catch (err) {
      setSaveError(err instanceof Error ? err.message : 'Could not save mood entry.');
    } finally {
      setSaving(false);
    }
  };

  const elapsedSec = routineTotalSec - countdownSec;
  const stepIndex = Math.min(
    GROUNDING_STEPS.length - 1,
    Math.floor((elapsedSec / Math.max(1, routineTotalSec)) * GROUNDING_STEPS.length)
  );
  const activeStep = GROUNDING_STEPS[stepIndex];

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="sos-title"
      className="fixed inset-0 z-50 flex flex-col overflow-y-auto bg-[#EEF2EF] text-[#242B27]"
    >
      {/* Top minimal bar */}
      <div className="mx-auto flex w-full max-w-5xl items-center justify-between gap-4 px-4 py-4 sm:px-8">
        <div>
          <p className="text-xs font-medium text-[#557463]">Exam Panic SOS · Distraction-Free Mode</p>
          <h2 id="sos-title" className="font-display text-xl font-medium text-[#242B27] sm:text-2xl">
            Let’s slow down together
          </h2>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={handleToggleRain}
            className="inline-flex items-center gap-2 rounded-lg border border-[#D4DDD7] bg-white px-3 py-2 text-xs font-medium text-[#242B27] hover:bg-[#FAF8F5] cursor-pointer"
          >
            {rainEnabled ? (
              <CloudRain className="h-4 w-4 text-[#557463]" />
            ) : (
              <VolumeX className="h-4 w-4 text-[#5C6660]" />
            )}
            <span>{rainEnabled ? 'Rain On' : 'Rain Off'}</span>
          </button>

          <button
            type="button"
            onClick={() => breathing.setChimesEnabled(!breathing.chimesEnabled)}
            className="inline-flex items-center gap-1.5 rounded-lg border border-[#D4DDD7] bg-white px-3 py-2 text-xs font-medium text-[#242B27] hover:bg-[#FAF8F5] cursor-pointer"
          >
            {breathing.chimesEnabled ? (
              <Volume2 className="h-4 w-4 text-[#557463]" />
            ) : (
              <VolumeX className="h-4 w-4 text-[#5C6660]" />
            )}
            <span className="hidden sm:inline">Cues</span>
          </button>

          <button
            type="button"
            onClick={onClose}
            className="inline-flex items-center gap-1.5 rounded-lg border border-[#D4DDD7] bg-white px-3.5 py-2 text-xs font-medium text-[#242B27] hover:bg-[#F3EFE8] cursor-pointer"
          >
            <X className="h-4 w-4" />
            <span>Exit</span>
          </button>
        </div>
      </div>

      {/* Main distraction-free workspace */}
      <div className="mx-auto flex w-full max-w-4xl flex-1 flex-col items-center justify-center px-4 pb-10 pt-2 sm:px-8">
        {stage === 'active' && (
          <div className="w-full space-y-6">
            {/* Before stress quick selector + Routine timer */}
            <div className="flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-[#D4DDD7] bg-white/85 px-5 py-4">
              <div className="flex flex-wrap items-center gap-3">
                <span className="text-xs font-medium text-[#5C6660]">Stress right now:</span>
                <div className="flex items-center gap-1.5">
                  {[1, 2, 3, 4, 5].map((lvl) => (
                    <button
                      key={lvl}
                      type="button"
                      onClick={() => setStressBefore(lvl)}
                      className={`h-8 w-8 rounded-lg font-mono-tabular text-xs font-semibold transition-colors cursor-pointer ${
                        stressBefore === lvl
                          ? 'bg-[#6D5B7B] text-white'
                          : 'border border-[#E5E0D8] bg-[#FAF8F5] text-[#5C6660] hover:bg-[#F3EFE8]'
                      }`}
                    >
                      {lvl}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1 rounded-lg border border-[#E5E0D8] bg-[#FAF8F5] p-0.5 text-xs">
                  <button
                    type="button"
                    onClick={() => handleSwitchDuration(120)}
                    className={`rounded-md px-2.5 py-1 font-medium cursor-pointer ${
                      routineTotalSec === 120 ? 'bg-white text-[#242B27] shadow-xs' : 'text-[#5C6660]'
                    }`}
                  >
                    2 min
                  </button>
                  <button
                    type="button"
                    onClick={() => handleSwitchDuration(60)}
                    className={`rounded-md px-2.5 py-1 font-medium cursor-pointer ${
                      routineTotalSec === 60 ? 'bg-white text-[#242B27] shadow-xs' : 'text-[#5C6660]'
                    }`}
                  >
                    60s demo
                  </button>
                </div>

                <div className="font-mono-tabular text-lg font-semibold text-[#242B27]">
                  {formatClock(countdownSec)}
                </div>
              </div>
            </div>

            {/* Breathing Circle + Step-by-step Grounding */}
            <div className="grid grid-cols-1 items-center gap-8 rounded-2xl border border-[#D4DDD7] bg-white p-6 sm:p-10 md:grid-cols-2">
              <div className="flex flex-col items-center">
                <div className="relative flex h-56 w-56 items-center justify-center">
                  <div
                    aria-hidden="true"
                    className="absolute inset-0 rounded-full border border-[#D4DDD7]"
                  />
                  <div
                    style={{ transform: `scale(${breathing.circleScale})` }}
                    className="flex h-44 w-44 flex-col items-center justify-center rounded-full border-2 border-[#557463] bg-[#E8F0EB] will-change-transform"
                  >
                    <span className="text-xs font-medium text-[#3B5246]">
                      {breathing.phaseLabel}
                    </span>
                    <span className="mt-1 font-mono-tabular text-5xl font-medium text-[#242B27]">
                      {breathing.phaseSecondsRemaining}
                    </span>
                  </div>
                </div>
                <p className="mt-4 text-center text-sm text-[#5C6660]">
                  {breathing.phaseInstruction}
                </p>
              </div>

              <div className="space-y-5">
                <div>
                  <p className="text-xs font-medium text-[#557463]">Grounding Step</p>
                  <h3 className="mt-1 font-display text-2xl font-medium text-[#242B27]">
                    {activeStep.title}
                  </h3>
                  <p className="mt-2 text-sm leading-relaxed text-[#5C6660]">
                    {activeStep.message}
                  </p>
                </div>

                <div className="space-y-2 border-t border-[#E5E0D8] pt-4 text-xs text-[#5C6660]">
                  {GROUNDING_STEPS.map((step, idx) => (
                    <div
                      key={step.title}
                      className={`flex items-center gap-2 ${
                        idx === stepIndex ? 'font-semibold text-[#242B27]' : 'opacity-65'
                      }`}
                    >
                      <span>{idx <= stepIndex ? '•' : '○'}</span>
                      <span>{step.title}</span>
                    </div>
                  ))}
                </div>

                <div className="pt-2">
                  <button
                    type="button"
                    onClick={handleFinishEarly}
                    className="rounded-lg bg-[#557463] px-5 py-2.5 text-sm font-medium text-white transition-colors hover:bg-[#466152] cursor-pointer"
                  >
                    Complete & Rate Stress
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {stage === 'rate-after' && (
          <div className="w-full max-w-xl rounded-2xl border border-[#D4DDD7] bg-white p-6 sm:p-10 animate-zen-enter">
            <p className="text-xs font-medium text-[#557463]">Post-Session Check-In</p>
            <h3 className="mt-1 font-display text-2xl font-medium text-[#242B27]">
              How does your stress feel now?
            </h3>
            <p className="mt-2 text-sm text-[#5C6660]">
              Compare how you feel after taking this pause. Saving will automatically update your weekly mood journal.
            </p>

            <div className="mt-6 grid grid-cols-1 gap-5 sm:grid-cols-2">
              <div className="rounded-xl border border-[#E5E0D8] bg-[#FAF8F5] p-4">
                <span className="text-xs font-medium text-[#5C6660]">Before Session</span>
                <div className="mt-2 flex gap-1.5">
                  {[1, 2, 3, 4, 5].map((n) => (
                    <button
                      key={n}
                      type="button"
                      onClick={() => setStressBefore(n)}
                      className={`h-9 flex-1 rounded-lg font-mono-tabular text-sm font-semibold cursor-pointer ${
                        stressBefore === n
                          ? 'bg-[#6D5B7B] text-white'
                          : 'border border-[#E5E0D8] bg-white text-[#5C6660]'
                      }`}
                    >
                      {n}
                    </button>
                  ))}
                </div>
              </div>

              <div className="rounded-xl border border-[#E5E0D8] bg-[#FAF8F5] p-4">
                <span className="text-xs font-medium text-[#5C6660]">After Session</span>
                <div className="mt-2 flex gap-1.5">
                  {[1, 2, 3, 4, 5].map((n) => (
                    <button
                      key={n}
                      type="button"
                      onClick={() => setStressAfter(n)}
                      className={`h-9 flex-1 rounded-lg font-mono-tabular text-sm font-semibold cursor-pointer ${
                        stressAfter === n
                          ? 'bg-[#557463] text-white'
                          : 'border border-[#E5E0D8] bg-white text-[#5C6660]'
                      }`}
                    >
                      {n}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {saveError && (
              <p className="mt-4 text-xs font-medium text-[#9A4242]">{saveError}</p>
            )}

            <div className="mt-6 flex flex-wrap items-center justify-end gap-3">
              <button
                type="button"
                onClick={onClose}
                className="rounded-lg border border-[#E5E0D8] bg-[#FAF8F5] px-4 py-2.5 text-sm font-medium text-[#242B27] hover:bg-[#F3EFE8] cursor-pointer"
              >
                Skip Saving
              </button>
              <button
                type="button"
                disabled={saving}
                onClick={() => void handleSaveSession()}
                className="rounded-lg bg-[#557463] px-5 py-2.5 text-sm font-medium text-white hover:bg-[#466152] disabled:opacity-60 cursor-pointer"
              >
                {saving ? 'Saving...' : 'Save to Mood Journal'}
              </button>
            </div>
          </div>
        )}

        {stage === 'saved' && (
          <div className="w-full max-w-lg rounded-2xl border border-[#D4DDD7] bg-white p-6 text-center sm:p-10 animate-zen-enter">
            <p className="text-xs font-medium text-[#557463]">Session Logged</p>
            <h3 className="mt-2 font-display text-3xl font-medium text-[#242B27]">
              {stressBefore > stressAfter
                ? `Stress eased from ${stressBefore} to ${stressAfter}`
                : 'Your check-in has been recorded'}
            </h3>
            <p className="mt-3 text-sm text-[#5C6660]">
              Your mood journal and weekly stress trend chart have been updated. Take one slow sip of water before returning to your notes.
            </p>
            <button
              type="button"
              onClick={onClose}
              className="mt-6 rounded-lg bg-[#557463] px-6 py-2.5 text-sm font-medium text-white hover:bg-[#466152] cursor-pointer"
            >
              Return to ZenZone
            </button>
          </div>
        )}

        <p className="mt-6 max-w-xl text-center text-xs text-[#5C6660]">
          ZenZone SOS offers calm breathing and grounding prompts for everyday study stress. It does not diagnose, treat, or replace professional mental health care.
        </p>
      </div>
    </div>
  );
}
