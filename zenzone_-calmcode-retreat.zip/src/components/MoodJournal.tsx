import {
  CategoryScale,
  Chart as ChartJS,
  Filler,
  Legend,
  LinearScale,
  LineElement,
  PointElement,
  Tooltip,
} from 'chart.js';
import { Edit2, Lightbulb, Plus, Trash2 } from 'lucide-react';
import { useState } from 'react';
import { Line } from 'react-chartjs-2';
import type { MoodLog, ReflectionPrompt, WeeklyStressPoint } from '../../shared/types/zenzone';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Tooltip,
  Filler,
  Legend
);

interface MoodJournalProps {
  logs: MoodLog[];
  weeklyTrend: WeeklyStressPoint[];
  prompts: ReflectionPrompt[];
  onSaveEntry: (payload: {
    stress_level: number;
    mood_emoji: string;
    reflection: string;
  }) => Promise<void>;
  onUpdateEntry: (
    id: number,
    payload: { stress_level: number; mood_emoji: string; reflection: string }
  ) => Promise<void>;
  onDeleteEntry: (id: number) => Promise<void>;
  loading?: boolean;
}

const MOOD_OPTIONS = [
  { emoji: '😌', label: 'Calm' },
  { emoji: '🙂', label: 'Steady' },
  { emoji: '😐', label: 'Neutral' },
  { emoji: '😟', label: 'Anxious' },
  { emoji: '😫', label: 'Overwhelmed' },
];

const STRESS_LABELS: Record<number, string> = {
  1: '1 · Very Calm',
  2: '2 · Mild Tension',
  3: '3 · Moderate Load',
  4: '4 · High Stress',
  5: '5 · Overwhelmed',
};

export function MoodJournal({
  logs,
  weeklyTrend,
  prompts,
  onSaveEntry,
  onUpdateEntry,
  onDeleteEntry,
  loading = false,
}: MoodJournalProps) {
  const [stressLevel, setStressLevel] = useState<number>(3);
  const [moodEmoji, setMoodEmoji] = useState<string>('🙂');
  const [reflection, setReflection] = useState<string>('');
  const [editingId, setEditingId] = useState<number | null>(null);
  const [promptIdx, setPromptIdx] = useState<number>(0);
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [statusNote, setStatusNote] = useState<string>('');

  const handleUsePrompt = () => {
    if (prompts.length === 0) return;
    const chosen = prompts[promptIdx % prompts.length];
    setPromptIdx((i) => i + 1);
    setReflection((prev) => (prev.trim() ? `${prev.trim()}\n\n${chosen.prompt}` : `${chosen.prompt} `));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setStatusNote('');
    try {
      if (editingId !== null) {
        await onUpdateEntry(editingId, {
          stress_level: stressLevel,
          mood_emoji: moodEmoji,
          reflection,
        });
        setEditingId(null);
        setStatusNote('Journal entry updated.');
      } else {
        await onSaveEntry({
          stress_level: stressLevel,
          mood_emoji: moodEmoji,
          reflection,
        });
        setStatusNote('Mood check-in saved.');
      }
      setReflection('');
      setStressLevel(3);
      setMoodEmoji('🙂');
    } finally {
      setSubmitting(false);
    }
  };

  const handleEditClick = (entry: MoodLog) => {
    setEditingId(entry.id);
    setStressLevel(entry.stress_level);
    setMoodEmoji(entry.mood_emoji);
    setReflection(entry.reflection);
    setStatusNote('');
  };

  const handleCancelEdit = () => {
    setEditingId(null);
    setStressLevel(3);
    setMoodEmoji('🙂');
    setReflection('');
  };

  const chartData = {
    labels: weeklyTrend.map((d) => d.label),
    datasets: [
      {
        label: 'Average Stress Level (1–5)',
        data: weeklyTrend.map((d) => d.avgStress),
        borderColor: '#557463',
        backgroundColor: 'rgba(85, 116, 99, 0.14)',
        pointBackgroundColor: '#557463',
        pointBorderColor: '#FFFFFF',
        pointBorderWidth: 2,
        pointRadius: 5,
        tension: 0.35,
        fill: true,
        spanGaps: true,
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      y: {
        min: 1,
        max: 5,
        ticks: {
          stepSize: 1,
          color: '#5C6660',
        },
        grid: {
          color: 'rgba(229, 224, 216, 0.7)',
        },
      },
      x: {
        ticks: {
          color: '#5C6660',
        },
        grid: {
          display: false,
        },
      },
    },
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        backgroundColor: '#242B27',
        padding: 10,
      },
    },
  };

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
      {/* Check-in form */}
      <form
        onSubmit={handleSubmit}
        className="rounded-2xl border border-[#E5E0D8] bg-white p-6 sm:p-8 lg:col-span-5"
      >
        <div className="flex items-start justify-between gap-4">
          <div>
            <p className="text-xs font-medium text-[#5C6660]">Daily Check-In</p>
            <h3 className="mt-1 font-display text-2xl font-medium text-[#242B27]">
              {editingId !== null ? 'Edit Mood Entry' : 'How are you holding up?'}
            </h3>
          </div>
          {editingId !== null && (
            <button
              type="button"
              onClick={handleCancelEdit}
              className="text-xs font-medium text-[#5C6660] hover:text-[#242B27] cursor-pointer"
            >
              Cancel Edit
            </button>
          )}
        </div>

        {/* Stress Slider */}
        <div className="mt-6">
          <div className="flex items-center justify-between text-sm">
            <label htmlFor="stress-slider" className="font-medium text-[#242B27]">
              Stress Level
            </label>
            <span className="font-mono-tabular text-xs font-medium text-[#557463]">
              {STRESS_LABELS[stressLevel]}
            </span>
          </div>
          <input
            id="stress-slider"
            type="range"
            min={1}
            max={5}
            step={1}
            value={stressLevel}
            onChange={(e) => setStressLevel(Number(e.target.value))}
            className="mt-3 h-2 w-full cursor-pointer accent-[#557463]"
          />
          <div className="mt-1 flex justify-between text-[11px] text-[#5C6660]">
            <span>1 (Calm)</span>
            <span>3 (Moderate)</span>
            <span>5 (High)</span>
          </div>
        </div>

        {/* Mood Emoji Selector */}
        <div className="mt-6">
          <span className="block text-sm font-medium text-[#242B27]">Mood</span>
          <div className="mt-2 grid grid-cols-5 gap-2">
            {MOOD_OPTIONS.map((opt) => {
              const selected = moodEmoji === opt.emoji;
              return (
                <button
                  key={opt.emoji}
                  type="button"
                  onClick={() => setMoodEmoji(opt.emoji)}
                  aria-pressed={selected}
                  className={`flex flex-col items-center rounded-xl border py-2.5 transition-colors cursor-pointer ${
                    selected
                      ? 'border-[#557463] bg-[#E8F0EB] text-[#242B27]'
                      : 'border-[#E5E0D8] bg-[#FAF8F5] text-[#5C6660] hover:bg-[#F3EFE8]'
                  }`}
                >
                  <span className="text-xl" aria-hidden="true">
                    {opt.emoji}
                  </span>
                  <span className="mt-1 text-[11px] font-medium">{opt.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Reflection + 20 Exam Prompts */}
        <div className="mt-6">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <label htmlFor="mood-reflection" className="text-sm font-medium text-[#242B27]">
              Short Reflection
            </label>
            <button
              type="button"
              onClick={handleUsePrompt}
              className="inline-flex items-center gap-1.5 text-xs font-medium text-[#74688F] hover:text-[#5B4B68] cursor-pointer"
            >
              <Lightbulb className="h-3.5 w-3.5" />
              <span>Insert Exam Prompt ({prompts.length})</span>
            </button>
          </div>
          <textarea
            id="mood-reflection"
            rows={4}
            maxLength={600}
            value={reflection}
            onChange={(e) => setReflection(e.target.value)}
            placeholder="Write a sentence or two about your study session, energy, or what would help next..."
            className="mt-2 w-full rounded-xl border border-[#E5E0D8] bg-[#FAF8F5] p-3 text-sm text-[#242B27] placeholder:text-[#8E9691] focus:border-[#557463] focus:bg-white focus:outline-none"
          />
        </div>

        {statusNote && (
          <p className="mt-3 text-xs font-medium text-[#557463]" role="status">
            {statusNote}
          </p>
        )}

        <button
          type="submit"
          disabled={submitting}
          className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-lg bg-[#557463] px-5 py-2.5 text-sm font-medium text-white transition-colors hover:bg-[#466152] disabled:opacity-60 cursor-pointer"
        >
          <Plus className="h-4 w-4" />
          <span>
            {submitting
              ? 'Saving...'
              : editingId !== null
              ? 'Update Journal Entry'
              : 'Save Journal Entry'}
          </span>
        </button>
      </form>

      {/* Chart + History */}
      <div className="space-y-6 lg:col-span-7">
        <div className="rounded-2xl border border-[#E5E0D8] bg-white p-6 sm:p-8">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <p className="text-xs font-medium text-[#5C6660]">7-Day Trend</p>
              <h3 className="mt-1 font-display text-2xl font-medium text-[#242B27]">
                Weekly Stress Pattern
              </h3>
            </div>
            <span className="font-mono-tabular text-xs text-[#5C6660]">
              {logs.length} {logs.length === 1 ? 'entry' : 'entries'} logged
            </span>
          </div>

          <div className="mt-5 h-56 w-full">
            {logs.length === 0 ? (
              <div className="flex h-full flex-col items-center justify-center rounded-xl border border-dashed border-[#D8D1C5] bg-[#FAF8F5] px-4 text-center">
                <p className="text-sm font-medium text-[#242B27]">No stress trend data yet</p>
                <p className="mt-1 max-w-sm text-xs text-[#5C6660]">
                  Save your first mood check-in or complete an Exam Panic SOS reset to watch your weekly curve update automatically.
                </p>
              </div>
            ) : (
              <Line data={chartData} options={chartOptions} />
            )}
          </div>
        </div>

        <div className="rounded-2xl border border-[#E5E0D8] bg-white p-6 sm:p-8">
          <h4 className="font-display text-xl font-medium text-[#242B27]">Previous Reflections</h4>

          {loading ? (
            <div className="mt-4 space-y-3">
              <div className="h-16 animate-pulse rounded-xl bg-[#F3EFE8]" />
              <div className="h-16 animate-pulse rounded-xl bg-[#F3EFE8]" />
            </div>
          ) : logs.length === 0 ? (
            <div className="mt-4 rounded-xl border border-dashed border-[#D8D1C5] bg-[#FAF8F5] p-6 text-center">
              <p className="text-sm font-medium text-[#242B27]">Your journal is quietly waiting</p>
              <p className="mt-1 text-xs text-[#5C6660]">
                Use the check-in panel on the left to record how you feel before or after studying.
              </p>
            </div>
          ) : (
            <ul className="mt-4 divide-y divide-[#E5E0D8]">
              {logs.map((entry) => (
                <li key={entry.id} className="py-4 first:pt-1 last:pb-1">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-start gap-3">
                      <span className="mt-0.5 text-2xl" aria-hidden="true">
                        {entry.mood_emoji}
                      </span>
                      <div>
                        <div className="flex flex-wrap items-center gap-2 text-xs text-[#5C6660]">
                          <span className="font-mono-tabular font-semibold text-[#242B27]">
                            Stress {entry.stress_level}/5
                          </span>
                          <span aria-hidden="true">·</span>
                          <span>
                            {new Date(entry.created_at.replace(' ', 'T')).toLocaleString('en-US', {
                              month: 'short',
                              day: 'numeric',
                              hour: 'numeric',
                              minute: '2-digit',
                            })}
                          </span>
                        </div>
                        <p className="mt-1 text-sm leading-relaxed text-[#242B27]">
                          {entry.reflection || 'Quick stress check-in recorded.'}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        type="button"
                        aria-label="Edit mood entry"
                        onClick={() => handleEditClick(entry)}
                        className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-[#5C6660] hover:bg-[#F3EFE8] hover:text-[#242B27] cursor-pointer"
                      >
                        <Edit2 className="h-3.5 w-3.5" />
                      </button>
                      <button
                        type="button"
                        aria-label="Delete mood entry"
                        onClick={() => void onDeleteEntry(entry.id)}
                        className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-[#5C6660] hover:bg-[#F7EBEB] hover:text-[#9A4242] cursor-pointer"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}
