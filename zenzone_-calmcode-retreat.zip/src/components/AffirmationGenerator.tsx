import { Bookmark, RefreshCw, Trash2 } from 'lucide-react';
import { useEffect, useState } from 'react';
import type { AffirmationSituation, FavoriteAffirmation } from '../../shared/types/zenzone';

interface AffirmationGeneratorProps {
  favorites: FavoriteAffirmation[];
  aiConfigured: boolean;
  onGenerate: (
    situation: AffirmationSituation,
    lastAffirmation?: string
  ) => Promise<{ affirmation: string; situation: AffirmationSituation; source: 'gemini' | 'local' }>;
  onSaveFavorite: (payload: {
    affirmation: string;
    situation: AffirmationSituation;
    source: 'gemini' | 'local';
  }) => Promise<void>;
  onDeleteFavorite: (id: number) => Promise<void>;
}

const SITUATIONS: Array<{ id: AffirmationSituation; label: string }> = [
  { id: 'before-exam', label: 'Before an Exam' },
  { id: 'imposter-syndrome', label: 'Imposter Syndrome' },
  { id: 'late-night-fatigue', label: 'Late-Night Fatigue' },
  { id: 'result-anxiety', label: 'Result Anxiety' },
  { id: 'general-confidence', label: 'General Confidence' },
];

export function AffirmationGenerator({
  favorites,
  aiConfigured,
  onGenerate,
  onSaveFavorite,
  onDeleteFavorite,
}: AffirmationGeneratorProps) {
  const [situation, setSituation] = useState<AffirmationSituation>('before-exam');
  const [currentText, setCurrentText] = useState<string>(
    'I have prepared honestly with the time I had, and I can meet each question calmly one line at a time.'
  );
  const [currentSource, setCurrentSource] = useState<'gemini' | 'local'>('local');
  const [loading, setLoading] = useState<boolean>(false);
  const [saving, setSaving] = useState<boolean>(false);

  const handleGenerate = async (targetSituation = situation) => {
    setLoading(true);
    try {
      const res = await onGenerate(targetSituation, currentText);
      setCurrentText(res.affirmation);
      setCurrentSource(res.source);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    // Load an initial affirmation for the default situation
    void handleGenerate('before-exam');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const isAlreadySaved = favorites.some((f) => f.affirmation === currentText);

  const handleSave = async () => {
    if (isAlreadySaved) return;
    setSaving(true);
    try {
      await onSaveFavorite({
        affirmation: currentText,
        situation,
        source: currentSource,
      });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="rounded-2xl border border-[#E5E0D8] bg-white p-6 sm:p-8">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-[#5C6660]">
            Exam Affirmations ·{' '}
            {aiConfigured && currentSource === 'gemini'
              ? 'AI Personalized'
              : 'Curated Local Affirmation Engine'}
          </p>
          <h3 className="mt-1 font-display text-2xl font-medium text-[#242B27]">
            Encouragement for This Moment
          </h3>
        </div>
      </div>

      {/* Situation selector */}
      <div className="mt-5 flex flex-wrap gap-2">
        {SITUATIONS.map((item) => {
          const active = situation === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => {
                setSituation(item.id);
                void handleGenerate(item.id);
              }}
              className={`rounded-lg border px-3 py-1.5 text-xs font-medium transition-colors cursor-pointer ${
                active
                  ? 'border-[#74688F] bg-[#EFEBF6] text-[#242B27]'
                  : 'border-[#E5E0D8] bg-[#FAF8F5] text-[#5C6660] hover:bg-[#F3EFE8]'
              }`}
            >
              {item.label}
            </button>
          );
        })}
      </div>

      {/* Generated Affirmation Display */}
      <div className="mt-5 rounded-2xl border border-[#E5E0D8] bg-[#FAF8F5] p-6">
        <p className="font-display text-xl leading-relaxed text-[#242B27] sm:text-2xl">
          “{currentText}”
        </p>

        <div className="mt-5 flex flex-wrap items-center gap-3">
          <button
            type="button"
            disabled={loading}
            onClick={() => void handleGenerate()}
            className="inline-flex items-center gap-2 rounded-lg bg-[#74688F] px-4 py-2 text-xs font-medium text-white transition-colors hover:bg-[#61567B] disabled:opacity-60 cursor-pointer"
          >
            <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span>{loading ? 'Generating...' : 'Another Affirmation'}</span>
          </button>

          <button
            type="button"
            disabled={saving || isAlreadySaved}
            onClick={() => void handleSave()}
            className="inline-flex items-center gap-2 rounded-lg border border-[#E5E0D8] bg-white px-4 py-2 text-xs font-medium text-[#242B27] transition-colors hover:bg-[#F3EFE8] disabled:opacity-60 cursor-pointer"
          >
            <Bookmark className="h-3.5 w-3.5 text-[#74688F]" />
            <span>{isAlreadySaved ? 'Saved to Favorites' : 'Save Favorite'}</span>
          </button>
        </div>
      </div>

      {/* Saved Favorites */}
      <div className="mt-6 border-t border-[#E5E0D8] pt-5">
        <div className="flex items-center justify-between text-xs text-[#5C6660]">
          <span className="font-medium text-[#242B27]">Saved Affirmations</span>
          <span className="font-mono-tabular">{favorites.length} saved</span>
        </div>

        {favorites.length === 0 ? (
          <p className="mt-3 text-xs text-[#5C6660]">
            Bookmark an affirmation above to keep it handy before entering your exam room.
          </p>
        ) : (
          <ul className="mt-3 space-y-2.5">
            {favorites.map((fav) => (
              <li
                key={fav.id}
                className="flex items-start justify-between gap-3 rounded-xl border border-[#E5E0D8] bg-[#FAF8F5] px-4 py-3 text-sm text-[#242B27]"
              >
                <div>
                  <p className="leading-relaxed">“{fav.affirmation}”</p>
                  <p className="mt-1 text-[11px] text-[#5C6660]">
                    {SITUATIONS.find((s) => s.id === fav.situation)?.label ?? fav.situation}
                  </p>
                </div>
                <button
                  type="button"
                  aria-label="Remove saved affirmation"
                  onClick={() => void onDeleteFavorite(fav.id)}
                  className="mt-0.5 inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-[#5C6660] hover:bg-white hover:text-[#9A4242] cursor-pointer"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
