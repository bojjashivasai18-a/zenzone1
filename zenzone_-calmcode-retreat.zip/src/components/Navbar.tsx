import { Menu, X } from 'lucide-react';
import { useState } from 'react';

export type NavSectionId = 'overview' | 'breathe-meditate' | 'yoga' | 'journal' | 'calm-wall';

interface NavbarProps {
  activeSection: NavSectionId;
  onNavigate: (section: NavSectionId) => void;
  onOpenSOS: () => void;
}

const NAV_ITEMS: Array<{ id: NavSectionId; label: string }> = [
  { id: 'overview', label: 'Overview' },
  { id: 'breathe-meditate', label: 'Breathe & Meditate' },
  { id: 'yoga', label: 'Desk Yoga' },
  { id: 'journal', label: 'Mood Journal' },
  { id: 'calm-wall', label: 'Calm Wall' },
];

export function Navbar({ activeSection, onNavigate, onOpenSOS }: NavbarProps) {
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleSelect = (id: NavSectionId) => {
    onNavigate(id);
    setMobileOpen(false);
  };

  return (
    <header className="sticky top-0 z-30 border-b border-[#E5E0D8] bg-[#FAF8F5]/95 backdrop-blur-sm">
      <div className="mx-auto flex max-w-[1200px] items-center justify-between gap-8 px-4 py-3.5 sm:px-6">
        <a
          href="#overview"
          onClick={(e) => {
            e.preventDefault();
            handleSelect('overview');
          }}
          className="font-display text-xl font-medium tracking-tight text-[#242B27] whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#557463]"
        >
          ZenZone
        </a>

        <nav
          aria-label="Primary navigation"
          className="hidden md:flex items-center gap-6 text-sm font-medium text-[#5C6660]"
        >
          {NAV_ITEMS.map((item) => {
            const isActive = activeSection === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handleSelect(item.id)}
                className={`relative py-1 whitespace-nowrap shrink-0 transition-colors duration-150 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#557463] ${
                  isActive
                    ? 'text-[#242B27] underline decoration-[#557463] decoration-2 underline-offset-8'
                    : 'hover:text-[#242B27] hover:underline hover:decoration-[#C9D5CD] hover:underline-offset-8'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </nav>

        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={onOpenSOS}
            className="rounded-lg bg-[#6D5B7B] px-4 py-2 text-sm font-medium text-[#FAF8F5] transition-colors duration-150 hover:bg-[#5B4B68] active:scale-[0.99] whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#6D5B7B]"
          >
            Exam Panic SOS
          </button>

          <button
            type="button"
            aria-label={mobileOpen ? 'Close navigation menu' : 'Open navigation menu'}
            aria-expanded={mobileOpen}
            onClick={() => setMobileOpen((prev) => !prev)}
            className="inline-flex h-10 w-10 items-center justify-center rounded-lg border border-[#E5E0D8] bg-white text-[#242B27] md:hidden cursor-pointer focus-visible:outline-2 focus-visible:outline-[#557463]"
          >
            {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {mobileOpen && (
        <nav
          aria-label="Mobile navigation"
          className="border-t border-[#E5E0D8] bg-[#FAF8F5] px-4 py-3 md:hidden"
        >
          <div className="flex flex-col gap-1">
            {NAV_ITEMS.map((item) => {
              const isActive = activeSection === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => handleSelect(item.id)}
                  className={`flex w-full items-center justify-between rounded-lg px-3 py-2.5 text-left text-sm font-medium transition-colors cursor-pointer ${
                    isActive
                      ? 'bg-[#E8F0EB] text-[#242B27]'
                      : 'text-[#5C6660] hover:bg-[#F3EFE8] hover:text-[#242B27]'
                  }`}
                >
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>
        </nav>
      )}
    </header>
  );
}
