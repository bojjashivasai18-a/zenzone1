import { Eye, Sparkles } from 'lucide-react';

interface PostureBreakOverlayProps {
  isOpen: boolean;
  elapsedMinutes: number;
  onDismiss: () => void;
  onTakeBreak: () => void;
}

export function PostureBreakOverlay({
  isOpen,
  elapsedMinutes,
  onDismiss,
  onTakeBreak,
}: PostureBreakOverlayProps) {
  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="posture-break-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-[#1F2622]/75 p-4 backdrop-blur-md"
    >
      <div className="w-full max-w-lg rounded-2xl border border-[#C6D5CB] bg-[#FAF8F5] p-6 shadow-2xl sm:p-8 animate-zen-enter">
        <div className="flex items-center gap-2 text-xs font-medium text-[#557463]">
          <Eye className="h-4 w-4" />
          <span>45-Minute Posture & Screen-Break Reminder</span>
        </div>

        <h3
          id="posture-break-title"
          className="mt-2 font-display text-2xl font-medium text-[#242B27] sm:text-3xl"
        >
          Rest your eyes and unroll your shoulders
        </h3>

        <p className="mt-3 text-sm leading-relaxed text-[#5C6660]">
          You have been studying continuously for{' '}
          <span className="font-mono-tabular font-semibold text-[#242B27]">{elapsedMinutes}</span>{' '}
          minutes. Look at something at least 20 feet away for 20 seconds and roll your shoulders back three times.
        </p>

        <div className="mt-5 grid grid-cols-1 gap-3 rounded-xl border border-[#E5E0D8] bg-white p-4 text-xs text-[#5C6660] sm:grid-cols-2">
          <div>
            <p className="font-semibold text-[#242B27]">20-20-20 Eye Rule</p>
            <p className="mt-1">Soften your gaze toward a window or far wall for 20 seconds.</p>
          </div>
          <div>
            <p className="font-semibold text-[#242B27]">Desk Posture Check</p>
            <p className="mt-1">Unclench your jaw, plant both feet flat, and drop your shoulders.</p>
          </div>
        </div>

        <div className="mt-6 flex flex-wrap items-center justify-end gap-3">
          <button
            type="button"
            onClick={onDismiss}
            className="rounded-lg border border-[#E5E0D8] bg-white px-4 py-2.5 text-sm font-medium text-[#242B27] hover:bg-[#F3EFE8] cursor-pointer"
          >
            Dismiss & Reset Timer
          </button>

          <button
            type="button"
            onClick={onTakeBreak}
            className="inline-flex items-center gap-2 rounded-lg bg-[#557463] px-5 py-2.5 text-sm font-medium text-white hover:bg-[#466152] cursor-pointer"
          >
            <Sparkles className="h-4 w-4" />
            <span>Take a Desk Yoga Break</span>
          </button>
        </div>
      </div>
    </div>
  );
}
