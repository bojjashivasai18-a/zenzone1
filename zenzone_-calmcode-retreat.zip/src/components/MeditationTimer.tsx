import { CheckCircle2, Flame, Pause, Play, RotateCcw } from 'lucide-react';
import { useCallback, useEffect, useRef, useState } from 'react';
import { soundEngine } from '../audio/SoundEngine';
import type { MeditationSummary } from '../../shared/types/zenzone';

interface MeditationTimerProps {
  summary: MeditationSummary;
  defaultMinutes?: number;
  onSessionCompleted: (durationSeconds: number) => Promise<void>;
  onActiveChange?: (isActive: boolean) => void;
}

const DURATION_OPTIONS = [2, 3, 5, 7, 10];
const CHIME_INTERVALS = [
  { label: 'Every 1 min', seconds: 60 },
  { label: 'Every 2 min', seconds: 120 },
  { label: 'End only', seconds: 0 },
];

function formatClock(totalSeconds: number): string {
  const mins = Math.floor(totalSeconds / 60);
  const secs = totalSeconds % 60;
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

export function MeditationTimer({
  summary,
  defaultMinutes = 5,
  onSessionCompleted,
  onActiveChange,
}: MeditationTimerProps) {
  const [selectedMinutes, setSelectedMinutes] = useState<number>(defaultMinutes);
  const [intervalChimeSec, setIntervalChimeSec] = useState<number>(60);
  const [secondsLeft, setSecondsLeft] = useState<number>(defaultMinutes * 60);
  const [status, setStatus] = useState<'idle' | 'running' | 'paused' | 'completed'>('idle');
  const [saving, setSaving] = useState<boolean>(false);

  const elapsedRef = useRef<number>(0);

  useEffect(() => {
    onActiveChange?.(status === 'running');
  }, [status, onActiveChange]);

  const handleSelectMinutes = (mins: number) => {
    if (status === 'running') return;
    setSelectedMinutes(mins);
    setSecondsLeft(mins * 60);
    setStatus('idle');
    elapsedRef.current = 0;
  };

  const finishSession = useCallback(async () => {
    setStatus('completed');
    soundEngine.playMeditationChime(true);
    setSaving(true);
    try {
      await onSessionCompleted(selectedMinutes * 60);
    } finally {
      setSaving(false);
    }
  }, [onSessionCompleted, selectedMinutes]);

  useEffect(() => {
    if (status !== 'running') return;

    const id = window.setInterval(() => {
      setSecondsLeft((prev) => {
        if (prev <= 1) {
          window.clearInterval(id);
          void finishSession();
          return 0;
        }
        const next = prev - 1;
        elapsedRef.current += 1;
        if (
          intervalChimeSec > 0 &&
          elapsedRef.current > 0 &&
          elapsedRef.current % intervalChimeSec === 0 &&
          next > 5
        ) {
          soundEngine.playMeditationChime(false);
        }
        return next;
      });
    }, 1000);

    return () => window.clearInterval(id);
  }, [status, intervalChimeSec, finishSession]);

  const handleStart = () => {
    soundEngine.playMeditationChime(false);
    elapsedRef.current = 0;
    if (status === 'completed' || secondsLeft === 0) {
      setSecondsLeft(selectedMinutes * 60);
    }
    setStatus('running');
  };

  const handleReset = () => {
    setStatus('idle');
    elapsedRef.current = 0;
    setSecondsLeft(selectedMinutes * 60);
  };

  const totalSec = selectedMinutes * 60;
  const progressPct = Math.round(((totalSec - secondsLeft) / totalSec) * 100);

  return (
    <div className="overflow-hidden rounded-2xl border border-[#E5E0D8] bg-white">
      <div className="relative overflow-hidden border-b border-[#E5E0D8] bg-[#E8F0EB] px-6 py-7 sm:px-8">
        <img
          src="/src/assets/images/zenzone_meditation_mist_1795673976655.jpg"
          alt="Calm Scandinavian eucalyptus and smooth river stones by a misty window"
          referrerPolicy="no-referrer"
          className="pointer-events-none absolute inset-0 h-full w-full object-cover opacity-30"
        />
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -right-10 -top-10 h-52 w-52 rounded-full bg-[#FAF8F5]/55 blur-2xl animate-zen-mist"
        />
        <div className="relative flex flex-wrap items-center justify-between gap-4">
          <div>
            <p className="text-xs font-medium text-[#3B5246]">Guided Meditation Timer</p>
            <h3 className="mt-1 font-display text-2xl font-medium text-[#242B27]">
              Quiet Study Reset
            </h3>
          </div>

          <div className="flex items-center gap-4 text-sm text-[#242B27]">
            <div className="flex items-center gap-1.5">
              <Flame className="h-4 w-4 text-[#557463]" />
              <span className="font-mono-tabular font-semibold">{summary.currentStreak}</span>
              <span className="text-xs text-[#4C5951]">day streak</span>
            </div>
            <span aria-hidden="true" className="text-[#9AA89F]">·</span>
            <div className="text-xs text-[#4C5951]">
              <span className="font-mono-tabular font-semibold text-[#242B27]">
                {summary.totalMinutes}
              </span>{' '}
              total mins
            </div>
          </div>
        </div>
      </div>

      <div className="p-6 sm:p-8">
        <div className="flex flex-col items-center py-4">
          <div className="relative flex h-44 w-44 items-center justify-center rounded-full border border-[#E5E0D8] bg-[#FAF8F5]">
            <div
              aria-hidden="true"
              className={`absolute inset-2 rounded-full border border-[#C6D5CB] ${
                status === 'running' ? 'animate-zen-ring' : ''
              }`}
            />
            <div className="text-center">
              <div className="font-mono-tabular text-4xl font-medium text-[#242B27]">
                {formatClock(secondsLeft)}
              </div>
              <div className="mt-1 text-xs text-[#5C6660]">
                {status === 'running'
                  ? 'Softening focus'
                  : status === 'completed'
                  ? 'Session complete'
                  : `${selectedMinutes} minute session`}
              </div>
            </div>
          </div>

          {/* Progress hairline */}
          <div className="mt-5 h-1.5 w-full max-w-xs overflow-hidden rounded-full bg-[#F3EFE8]">
            <div
              className="h-full bg-[#557463] transition-all duration-300"
              style={{ width: `${progressPct}%` }}
            />
          </div>

          {status === 'completed' && (
            <div className="mt-5 flex items-center gap-2 rounded-xl border border-[#C6D5CB] bg-[#E8F0EB] px-4 py-3 text-sm text-[#242B27]">
              <CheckCircle2 className="h-4 w-4 shrink-0 text-[#557463]" />
              <span>
                {saving
                  ? 'Saving your meditation session...'
                  : 'Well done. Your meditation session and daily streak have been recorded.'}
              </span>
            </div>
          )}

          {/* Duration selector (2 to 10 minutes) */}
          <div className="mt-6 flex flex-wrap items-center justify-center gap-2">
            {DURATION_OPTIONS.map((mins) => {
              const active = selectedMinutes === mins;
              return (
                <button
                  key={mins}
                  type="button"
                  disabled={status === 'running'}
                  onClick={() => handleSelectMinutes(mins)}
                  className={`rounded-lg border px-3 py-1.5 font-mono-tabular text-xs font-medium transition-colors cursor-pointer disabled:cursor-not-allowed disabled:opacity-50 ${
                    active
                      ? 'border-[#557463] bg-[#E8F0EB] text-[#242B27]'
                      : 'border-[#E5E0D8] bg-[#FAF8F5] text-[#5C6660] hover:bg-[#F3EFE8]'
                  }`}
                >
                  {mins}m
                </button>
              );
            })}
          </div>

          {/* Interval chime selector */}
          <div className="mt-3 flex flex-wrap items-center justify-center gap-2 text-xs text-[#5C6660]">
            <span>Interval chime:</span>
            {CHIME_INTERVALS.map((opt) => (
              <button
                key={opt.label}
                type="button"
                disabled={status === 'running'}
                onClick={() => setIntervalChimeSec(opt.seconds)}
                className={`rounded-md px-2.5 py-1 transition-colors cursor-pointer ${
                  intervalChimeSec === opt.seconds
                    ? 'bg-[#EFEBF6] font-medium text-[#242B27]'
                    : 'hover:bg-[#F3EFE8]'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>

          {/* Action buttons */}
          <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
            {(status === 'idle' || status === 'completed') && (
              <button
                type="button"
                onClick={handleStart}
                className="inline-flex items-center gap-2 rounded-lg bg-[#557463] px-5 py-2.5 text-sm font-medium text-white transition-colors hover:bg-[#466152] cursor-pointer"
              >
                <Play className="h-4 w-4" />
                <span>{status === 'completed' ? 'Start Another' : 'Start Meditation'}</span>
              </button>
            )}

            {status === 'running' && (
              <button
                type="button"
                onClick={() => setStatus('paused')}
                className="inline-flex items-center gap-2 rounded-lg bg-[#5A7B8C] px-5 py-2.5 text-sm font-medium text-white transition-colors hover:bg-[#496777] cursor-pointer"
              >
                <Pause className="h-4 w-4" />
                <span>Pause</span>
              </button>
            )}

            {status === 'paused' && (
              <button
                type="button"
                onClick={() => setStatus('running')}
                className="inline-flex items-center gap-2 rounded-lg bg-[#557463] px-5 py-2.5 text-sm font-medium text-white transition-colors hover:bg-[#466152] cursor-pointer"
              >
                <Play className="h-4 w-4" />
                <span>Resume</span>
              </button>
            )}

            {status !== 'idle' && (
              <button
                type="button"
                onClick={handleReset}
                className="inline-flex items-center gap-2 rounded-lg border border-[#E5E0D8] bg-[#FAF8F5] px-4 py-2.5 text-sm font-medium text-[#242B27] hover:bg-[#F3EFE8] cursor-pointer"
              >
                <RotateCcw className="h-4 w-4" />
                <span>Reset</span>
              </button>
            )}
          </div>
        </div>

        {/* Recent session history */}
        <div className="mt-6 border-t border-[#E5E0D8] pt-5">
          <div className="flex items-center justify-between text-xs text-[#5C6660]">
            <span className="font-medium text-[#242B27]">Recent Sessions</span>
            <span className="font-mono-tabular">{summary.totalSessions} completed</span>
          </div>

          {summary.sessions.length === 0 ? (
            <p className="mt-3 text-xs text-[#5C6660]">
              No meditation sessions logged yet. Complete a 2–10 minute pause to start your daily streak.
            </p>
          ) : (
            <ul className="mt-3 divide-y divide-[#E5E0D8] text-xs">
              {summary.sessions.slice(0, 4).map((s) => (
                <li key={s.id} className="flex items-center justify-between py-2">
                  <span className="text-[#242B27]">
                    {Math.round(s.duration / 60)} min Guided Reset
                  </span>
                  <span className="font-mono-tabular text-[#5C6660]">
                    {new Date(s.session_date.replace(' ', 'T')).toLocaleDateString('en-US', {
                      month: 'short',
                      day: 'numeric',
                    })}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}
