import { Bell, CloudRain, Pause, Play, Radio, Square, Trees } from 'lucide-react';
import { useEffect, useState } from 'react';
import { soundEngine } from '../audio/SoundEngine';
import type { SoundTrackId } from '../../shared/types/zenzone';

interface AmbientSoundscapeProps {
  initialVolumes?: Record<SoundTrackId, number>;
  onVolumesChange?: (volumes: Record<SoundTrackId, number>) => void;
}

const SOUND_TRACKS: Array<{
  id: SoundTrackId;
  title: string;
  subtitle: string;
  Icon: typeof CloudRain;
}> = [
  {
    id: 'rain',
    title: 'Gentle Rain',
    subtitle: 'Soft steady rainfall for study focus',
    Icon: CloudRain,
  },
  {
    id: 'birds',
    title: 'Forest Birds',
    subtitle: 'Nordic woodland breeze & soft songbirds',
    Icon: Trees,
  },
  {
    id: 'whitenoise',
    title: 'White Noise',
    subtitle: 'Warm filtered acoustic masking',
    Icon: Radio,
  },
  {
    id: 'bells',
    title: 'Temple Bells',
    subtitle: 'Resonant singing bowl chimes every few seconds',
    Icon: Bell,
  },
];

export function AmbientSoundscape({ initialVolumes, onVolumesChange }: AmbientSoundscapeProps) {
  const [volumes, setVolumes] = useState<Record<SoundTrackId, number>>(
    initialVolumes ?? {
      rain: 0.45,
      birds: 0.35,
      whitenoise: 0.25,
      bells: 0.35,
    }
  );
  const [activeTracks, setActiveTracks] = useState<SoundTrackId[]>(() =>
    soundEngine.getActiveTracks()
  );

  // Sync if parent updates volumes from saved preferences
  useEffect(() => {
    if (initialVolumes) {
      setVolumes(initialVolumes);
    }
  }, [initialVolumes]);

  // Periodically sync active tracks in case SOS mode started/stopped rain
  useEffect(() => {
    const sync = () => setActiveTracks(soundEngine.getActiveTracks());
    const id = window.setInterval(sync, 500);
    return () => window.clearInterval(id);
  }, []);

  const handleToggle = (id: SoundTrackId) => {
    soundEngine.toggleTrack(id, volumes[id]);
    setActiveTracks(soundEngine.getActiveTracks());
  };

  const handleVolumeChange = (id: SoundTrackId, nextVal: number) => {
    const next = { ...volumes, [id]: nextVal };
    setVolumes(next);
    soundEngine.setTrackVolume(id, nextVal);
    onVolumesChange?.(next);
  };

  const handleStopAll = () => {
    soundEngine.stopAllAmbient();
    setActiveTracks([]);
  };

  return (
    <div className="rounded-2xl border border-[#E5E0D8] bg-white p-6 sm:p-8">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-[#5C6660]">Web Audio Mixer</p>
          <h3 className="mt-1 font-display text-2xl font-medium text-[#242B27]">
            Ambient Soundscape
          </h3>
          <p className="mt-1 text-sm text-[#5C6660]">
            Layer multiple calming sounds together and adjust each track independently.
          </p>
        </div>

        <button
          type="button"
          onClick={handleStopAll}
          disabled={activeTracks.length === 0}
          className="inline-flex items-center gap-2 rounded-lg border border-[#E5E0D8] bg-[#FAF8F5] px-3.5 py-2 text-xs font-medium text-[#242B27] transition-colors hover:bg-[#F3EFE8] disabled:cursor-not-allowed disabled:opacity-45 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-[#557463]"
        >
          <Square className="h-3.5 w-3.5" />
          <span>Stop All Sounds</span>
        </button>
      </div>

      <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2">
        {SOUND_TRACKS.map(({ id, title, subtitle, Icon }) => {
          const isPlaying = activeTracks.includes(id);
          const pct = Math.round(volumes[id] * 100);

          return (
            <div
              key={id}
              className={`rounded-xl border p-4 transition-colors duration-150 ${
                isPlaying
                  ? 'border-[#557463] bg-[#F4F8F5]'
                  : 'border-[#E5E0D8] bg-[#FAF8F5]'
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-3">
                  <div
                    className={`mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-lg ${
                      isPlaying ? 'bg-[#557463] text-white' : 'bg-[#E5E0D8]/70 text-[#5C6660]'
                    }`}
                  >
                    <Icon className="h-4 w-4" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="text-sm font-semibold text-[#242B27]">{title}</h4>
                      {isPlaying && (
                        <span className="text-xs font-medium text-[#557463]">Playing</span>
                      )}
                    </div>
                    <p className="mt-0.5 text-xs text-[#5C6660]">{subtitle}</p>
                  </div>
                </div>

                <button
                  type="button"
                  aria-label={isPlaying ? `Pause ${title}` : `Play ${title}`}
                  onClick={() => handleToggle(id)}
                  className={`inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border transition-colors cursor-pointer focus-visible:outline-2 focus-visible:outline-[#557463] ${
                    isPlaying
                      ? 'border-[#557463] bg-white text-[#557463] hover:bg-[#E8F0EB]'
                      : 'border-[#E5E0D8] bg-white text-[#242B27] hover:bg-[#F3EFE8]'
                  }`}
                >
                  {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                </button>
              </div>

              <div className="mt-4 flex items-center gap-3">
                <label htmlFor={`vol-${id}`} className="text-xs text-[#5C6660] shrink-0">
                  Volume
                </label>
                <input
                  id={`vol-${id}`}
                  type="range"
                  min={0}
                  max={100}
                  value={pct}
                  onChange={(e) => handleVolumeChange(id, Number(e.target.value) / 100)}
                  className="h-1.5 w-full cursor-pointer accent-[#557463]"
                />
                <span className="w-9 text-right font-mono-tabular text-xs text-[#242B27]">
                  {pct}%
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
