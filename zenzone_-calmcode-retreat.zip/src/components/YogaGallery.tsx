import { CheckCircle2, Clock, Pause, Play, RotateCcw, X } from 'lucide-react';
import { useEffect, useState } from 'react';
import type { YogaPose } from '../../shared/types/zenzone';
import { YogaPoseIllustration } from './YogaPoseIllustration';

interface YogaGalleryProps {
  poses: YogaPose[];
  previewOnly?: boolean;
  onViewAll?: () => void;
}

export function YogaGallery({ poses, previewOnly = false, onViewAll }: YogaGalleryProps) {
  const [selectedArea, setSelectedArea] = useState<string>('All');
  const [activePose, setActivePose] = useState<YogaPose | null>(null);
  const [timerSecondsLeft, setTimerSecondsLeft] = useState<number>(0);
  const [timerRunning, setTimerRunning] = useState<boolean>(false);
  const [completedPoseIds, setCompletedPoseIds] = useState<Set<string>>(new Set());

  const areas = ['All', 'Neck & Upper Body', 'Spine & Back', 'Hands & Eyes'];

  const filterPose = (pose: YogaPose) => {
    if (selectedArea === 'All') return true;
    if (selectedArea === 'Neck & Upper Body') {
      return ['neck-stretches', 'shoulder-rolls', 'seated-side-stretch'].includes(pose.id);
    }
    if (selectedArea === 'Spine & Back') {
      return [
        'seated-spinal-twist',
        'seated-forward-bend',
        'upper-back-stretch',
        'seated-cat-cow',
      ].includes(pose.id);
    }
    return ['wrist-stretches', 'eye-relaxation', 'ankle-rotations'].includes(pose.id);
  };

  const displayedPoses = previewOnly ? poses.slice(0, 3) : poses.filter(filterPose);

  useEffect(() => {
    if (!timerRunning || !activePose) return;

    const id = window.setInterval(() => {
      setTimerSecondsLeft((prev) => {
        if (prev <= 1) {
          setTimerRunning(false);
          setCompletedPoseIds((curr) => new Set(curr).add(activePose.id));
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => window.clearInterval(id);
  }, [timerRunning, activePose]);

  const openPoseTimer = (pose: YogaPose, autoStart = false) => {
    setActivePose(pose);
    setTimerSecondsLeft(pose.durationSeconds);
    setTimerRunning(autoStart);
  };

  const closePoseModal = () => {
    setTimerRunning(false);
    setActivePose(null);
  };

  return (
    <div className="space-y-6">
      {!previewOnly && (
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-1.5 rounded-xl border border-[#E5E0D8] bg-[#F3EFE8] p-1">
            {areas.map((area) => {
              const active = selectedArea === area;
              return (
                <button
                  key={area}
                  type="button"
                  onClick={() => setSelectedArea(area)}
                  className={`rounded-lg px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    active
                      ? 'bg-white text-[#242B27] shadow-xs'
                      : 'text-[#5C6660] hover:text-[#242B27]'
                  }`}
                >
                  {area}
                </button>
              );
            })}
          </div>

          <p className="text-xs text-[#5C6660]">
            Showing <span className="font-mono-tabular font-semibold text-[#242B27]">{displayedPoses.length}</span> of{' '}
            <span className="font-mono-tabular font-semibold text-[#242B27]">{poses.length}</span> desk poses
          </p>
        </div>
      )}

      {!previewOnly && (
        <div className="overflow-hidden rounded-2xl border border-[#E5E0D8] bg-white">
          <div className="grid grid-cols-1 items-stretch lg:grid-cols-12">
            <div className="flex flex-col justify-center p-6 sm:p-8 lg:col-span-7">
              <p className="text-xs font-medium text-[#5C6660]">Desk Reset · 10 Gentle Poses</p>
              <h3 className="mt-1 font-display text-2xl font-medium text-[#242B27] sm:text-3xl">
                Release neck, wrist, and spine tension without leaving your chair
              </h3>
              <p className="mt-3 max-w-xl text-sm leading-relaxed text-[#5C6660]">
                Each movement pairs slow breathing with 40–60 seconds of gentle mobility designed for dorm desks and quiet library corners.
              </p>
            </div>
            <div className="relative min-h-[180px] bg-[#E8F0EB] lg:col-span-5">
              <img
                src="/src/assets/images/zenzone_yoga_corner_1795673978768.jpg"
                alt="Sunlit Scandinavian corner with linen cushion and eucalyptus plant"
                referrerPolicy="no-referrer"
                className="h-full w-full object-cover"
              />
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-3">
        {displayedPoses.map((pose) => {
          const isDone = completedPoseIds.has(pose.id);
          return (
            <article
              key={pose.id}
              className="flex flex-col justify-between rounded-2xl border border-[#E5E0D8] bg-white p-6 transition-colors hover:border-[#C5D2C9]"
            >
              <div>
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2 text-xs text-[#5C6660]">
                      <span>{pose.focusArea}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono-tabular">{pose.durationSeconds}s</span>
                    </div>
                    <h4 className="mt-1 font-display text-xl font-medium text-[#242B27]">
                      {pose.name}
                    </h4>
                  </div>
                  <YogaPoseIllustration
                    illustrationKey={pose.illustrationKey}
                    className="h-16 w-16 shrink-0"
                  />
                </div>

                <ol className="mt-4 space-y-1.5 text-sm text-[#5C6660]">
                  {pose.steps.map((step, idx) => (
                    <li key={idx} className="flex gap-2">
                      <span className="font-mono-tabular text-xs font-medium text-[#557463] mt-0.5">
                        {idx + 1}.
                      </span>
                      <span>{step}</span>
                    </li>
                  ))}
                </ol>

                <p className="mt-4 rounded-xl bg-[#FAF8F5] px-3.5 py-2.5 text-xs leading-relaxed text-[#5C6660]">
                  <strong className="font-semibold text-[#242B27]">Breath:</strong> {pose.breathingPrompt}
                </p>

                <ul className="mt-3 space-y-1 text-xs text-[#5C6660]">
                  {pose.benefits.slice(0, 2).map((b, idx) => (
                    <li key={idx}>• {b}</li>
                  ))}
                </ul>
              </div>

              <div className="mt-5 flex items-center justify-between gap-3 border-t border-[#E5E0D8] pt-4">
                <button
                  type="button"
                  onClick={() => openPoseTimer(pose, true)}
                  className="inline-flex items-center gap-2 rounded-lg bg-[#557463] px-4 py-2 text-xs font-medium text-white transition-colors hover:bg-[#466152] whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-[#557463]"
                >
                  <Play className="h-3.5 w-3.5" />
                  <span>Start {pose.durationSeconds}s Timer</span>
                </button>

                {isDone && (
                  <span className="inline-flex items-center gap-1 text-xs font-medium text-[#557463]">
                    <CheckCircle2 className="h-4 w-4" />
                    Done
                  </span>
                )}
              </div>
            </article>
          );
        })}
      </div>

      {previewOnly && onViewAll && (
        <div className="flex justify-end">
          <button
            type="button"
            onClick={onViewAll}
            className="rounded-lg border border-[#E5E0D8] bg-white px-4 py-2 text-sm font-medium text-[#242B27] transition-colors hover:bg-[#F3EFE8] cursor-pointer"
          >
            Explore All 10 Desk Poses
          </button>
        </div>
      )}

      {/* Guided Pose Timer Modal */}
      {activePose && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="pose-modal-title"
          className="fixed inset-0 z-50 flex items-center justify-center bg-[#242B27]/45 p-4 backdrop-blur-xs"
        >
          <div className="w-full max-w-lg rounded-2xl border border-[#E5E0D8] bg-[#FAF8F5] p-6 shadow-xl sm:p-8 animate-zen-enter">
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="text-xs font-medium text-[#5C6660]">
                  {activePose.focusArea} · Recommended {activePose.durationSeconds}s
                </p>
                <h3 id="pose-modal-title" className="mt-1 font-display text-2xl font-medium text-[#242B27]">
                  {activePose.name}
                </h3>
              </div>
              <button
                type="button"
                onClick={closePoseModal}
                aria-label="Close pose timer"
                className="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-[#E5E0D8] bg-white text-[#5C6660] hover:text-[#242B27] cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="mt-6 flex flex-col items-center rounded-2xl border border-[#E5E0D8] bg-white p-6">
              <YogaPoseIllustration illustrationKey={activePose.illustrationKey} className="h-28 w-28" />

              <div className="mt-4 flex items-center gap-2 font-mono-tabular text-4xl font-medium text-[#242B27]">
                <Clock className="h-6 w-6 text-[#557463]" />
                <span>{timerSecondsLeft}s</span>
              </div>

              {timerSecondsLeft === 0 ? (
                <p className="mt-2 text-sm font-medium text-[#557463]">
                  Pose complete. Take one slow breath before returning to your desk.
                </p>
              ) : (
                <p className="mt-2 text-center text-xs text-[#5C6660]">{activePose.breathingPrompt}</p>
              )}

              <div className="mt-5 flex items-center gap-3">
                {timerSecondsLeft > 0 && (
                  <button
                    type="button"
                    onClick={() => setTimerRunning((r) => !r)}
                    className="inline-flex items-center gap-2 rounded-lg bg-[#557463] px-5 py-2 text-sm font-medium text-white hover:bg-[#466152] cursor-pointer"
                  >
                    {timerRunning ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                    <span>{timerRunning ? 'Pause' : 'Resume'}</span>
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => {
                    setTimerSecondsLeft(activePose.durationSeconds);
                    setTimerRunning(true);
                  }}
                  className="inline-flex items-center gap-2 rounded-lg border border-[#E5E0D8] bg-[#FAF8F5] px-4 py-2 text-sm font-medium text-[#242B27] hover:bg-[#F3EFE8] cursor-pointer"
                >
                  <RotateCcw className="h-4 w-4" />
                  <span>Restart</span>
                </button>
              </div>
            </div>

            <div className="mt-5 space-y-2 text-sm text-[#5C6660]">
              {activePose.steps.map((step, idx) => (
                <p key={idx}>
                  <span className="font-mono-tabular font-semibold text-[#557463]">{idx + 1}. </span>
                  {step}
                </p>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
