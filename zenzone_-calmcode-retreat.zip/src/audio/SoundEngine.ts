import type { BreathingPhase, SoundTrackId } from '../../shared/types/zenzone';

interface ActiveTrack {
  gain: GainNode;
  cleanup: () => void;
}

class ZenSoundEngine {
  private ctx: AudioContext | null = null;
  private activeTracks = new Map<SoundTrackId, ActiveTrack>();
  private trackVolumes: Record<SoundTrackId, number> = {
    rain: 0.45,
    birds: 0.35,
    whitenoise: 0.25,
    bells: 0.35,
  };

  // Binaural beats nodes
  private binauralLeftOsc: OscillatorNode | null = null;
  private binauralRightOsc: OscillatorNode | null = null;
  private binauralMasterGain: GainNode | null = null;
  private binauralActive = false;
  private binauralBaseHz = 200;

  private ensureContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return null;
      this.ctx = new AudioCtx();
    }
    if (this.ctx.state === 'suspended') {
      void this.ctx.resume().catch(() => {
        // Ignore resume failure if not in direct user gesture
      });
    }
    return this.ctx;
  }

  private createNoiseBuffer(ctx: AudioContext, seconds = 3, type: 'white' | 'pink' = 'pink'): AudioBuffer {
    const sampleRate = ctx.sampleRate;
    const length = sampleRate * seconds;
    const buffer = ctx.createBuffer(1, length, sampleRate);
    const data = buffer.getChannelData(0);

    if (type === 'white') {
      for (let i = 0; i < length; i++) {
        data[i] = Math.random() * 2 - 1;
      }
      return buffer;
    }

    // Paul Kellet's refined pink noise filter
    let b0 = 0;
    let b1 = 0;
    let b2 = 0;
    let b3 = 0;
    let b4 = 0;
    let b5 = 0;
    let b6 = 0;
    for (let i = 0; i < length; i++) {
      const white = Math.random() * 2 - 1;
      b0 = 0.99886 * b0 + white * 0.0555179;
      b1 = 0.99332 * b1 + white * 0.0750759;
      b2 = 0.96900 * b2 + white * 0.1538520;
      b3 = 0.86650 * b3 + white * 0.3104856;
      b4 = 0.55000 * b4 + white * 0.5329522;
      b5 = -0.7616 * b5 - white * 0.0168980;
      data[i] = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362) * 0.08;
      b6 = white * 0.115926;
    }
    return buffer;
  }

  public isTrackPlaying(track: SoundTrackId): boolean {
    return this.activeTracks.has(track);
  }

  public getActiveTracks(): SoundTrackId[] {
    return Array.from(this.activeTracks.keys());
  }

  public setTrackVolume(track: SoundTrackId, volume: number): void {
    const clamped = Math.max(0, Math.min(1, volume));
    this.trackVolumes[track] = clamped;
    const active = this.activeTracks.get(track);
    if (active && this.ctx) {
      active.gain.gain.setTargetAtTime(clamped * 0.45, this.ctx.currentTime, 0.08);
    }
  }

  public startTrack(track: SoundTrackId, volume?: number): boolean {
    const ctx = this.ensureContext();
    if (!ctx) return false;
    if (typeof volume === 'number') {
      this.trackVolumes[track] = Math.max(0, Math.min(1, volume));
    }
    if (this.activeTracks.has(track)) {
      this.setTrackVolume(track, this.trackVolumes[track]);
      return true;
    }

    const masterGain = ctx.createGain();
    masterGain.gain.setValueAtTime(0.0001, ctx.currentTime);
    masterGain.connect(ctx.destination);

    const targetGain = this.trackVolumes[track] * 0.45;
    masterGain.gain.setTargetAtTime(targetGain, ctx.currentTime, 0.25);

    let cleanup = () => {};

    if (track === 'rain') {
      const noiseSrc = ctx.createBufferSource();
      noiseSrc.buffer = this.createNoiseBuffer(ctx, 4, 'pink');
      noiseSrc.loop = true;

      const lowpass = ctx.createBiquadFilter();
      lowpass.type = 'lowpass';
      lowpass.frequency.value = 1150;

      const shimmerSrc = ctx.createBufferSource();
      shimmerSrc.buffer = this.createNoiseBuffer(ctx, 3, 'white');
      shimmerSrc.loop = true;

      const bandpass = ctx.createBiquadFilter();
      bandpass.type = 'bandpass';
      bandpass.frequency.value = 3200;
      bandpass.Q.value = 1.4;

      const shimmerGain = ctx.createGain();
      shimmerGain.gain.value = 0.045;

      noiseSrc.connect(lowpass);
      lowpass.connect(masterGain);

      shimmerSrc.connect(bandpass);
      bandpass.connect(shimmerGain);
      shimmerGain.connect(masterGain);

      noiseSrc.start();
      shimmerSrc.start();

      cleanup = () => {
        try {
          noiseSrc.stop();
          shimmerSrc.stop();
          noiseSrc.disconnect();
          shimmerSrc.disconnect();
        } catch {
          // Ignore already stopped source
        }
      };
    } else if (track === 'whitenoise') {
      const noiseSrc = ctx.createBufferSource();
      noiseSrc.buffer = this.createNoiseBuffer(ctx, 4, 'white');
      noiseSrc.loop = true;

      const warmFilter = ctx.createBiquadFilter();
      warmFilter.type = 'lowpass';
      warmFilter.frequency.value = 1800;

      const innerGain = ctx.createGain();
      innerGain.gain.value = 0.28;

      noiseSrc.connect(warmFilter);
      warmFilter.connect(innerGain);
      innerGain.connect(masterGain);
      noiseSrc.start();

      cleanup = () => {
        try {
          noiseSrc.stop();
          noiseSrc.disconnect();
        } catch {
          // Ignore
        }
      };
    } else if (track === 'birds') {
      // Gentle breeze bed + natural soft bird chirps
      const breeze = ctx.createBufferSource();
      breeze.buffer = this.createNoiseBuffer(ctx, 4, 'pink');
      breeze.loop = true;

      const breezeFilter = ctx.createBiquadFilter();
      breezeFilter.type = 'bandpass';
      breezeFilter.frequency.value = 550;
      breezeFilter.Q.value = 0.7;

      const breezeGain = ctx.createGain();
      breezeGain.gain.value = 0.14;

      breeze.connect(breezeFilter);
      breezeFilter.connect(breezeGain);
      breezeGain.connect(masterGain);
      breeze.start();

      const triggerChirp = () => {
        if (!this.ctx || !this.activeTracks.has('birds')) return;
        const now = this.ctx.currentTime;
        const notes = 2 + Math.floor(Math.random() * 2);
        const baseFreq = 1950 + Math.random() * 900;

        for (let i = 0; i < notes; i++) {
          const startAt = now + i * 0.14;
          const osc = this.ctx.createOscillator();
          const noteGain = this.ctx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(baseFreq, startAt);
          osc.frequency.exponentialRampToValueAtTime(baseFreq * (1.15 + Math.random() * 0.12), startAt + 0.06);
          osc.frequency.exponentialRampToValueAtTime(baseFreq * 0.92, startAt + 0.12);

          noteGain.gain.setValueAtTime(0.0001, startAt);
          noteGain.gain.linearRampToValueAtTime(0.09, startAt + 0.025);
          noteGain.gain.exponentialRampToValueAtTime(0.0001, startAt + 0.13);

          osc.connect(noteGain);
          noteGain.connect(masterGain);
          osc.start(startAt);
          osc.stop(startAt + 0.14);
        }
      };

      triggerChirp();
      const intervalId = window.setInterval(() => {
        if (Math.random() > 0.25) triggerChirp();
      }, 2800);

      cleanup = () => {
        window.clearInterval(intervalId);
        try {
          breeze.stop();
          breeze.disconnect();
        } catch {
          // Ignore
        }
      };
    } else if (track === 'bells') {
      const strikeBell = () => {
        if (!this.ctx || !this.activeTracks.has('bells')) return;
        const now = this.ctx.currentTime;
        const pitches = [293.66, 329.63, 392.0, 440.0]; // D4, E4, G4, A4 calm pentatonic
        const root = pitches[Math.floor(Math.random() * pitches.length)];
        const partials = [
          { ratio: 1, amp: 0.24, decay: 4.5 },
          { ratio: 2.0, amp: 0.08, decay: 3.2 },
          { ratio: 2.76, amp: 0.04, decay: 2.0 },
        ];

        for (const p of partials) {
          const osc = this.ctx.createOscillator();
          const g = this.ctx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(root * p.ratio, now);
          g.gain.setValueAtTime(0.0001, now);
          g.gain.linearRampToValueAtTime(p.amp, now + 0.03);
          g.gain.exponentialRampToValueAtTime(0.0001, now + p.decay);

          osc.connect(g);
          g.connect(masterGain);
          osc.start(now);
          osc.stop(now + p.decay + 0.05);
        }
      };

      const timer = window.setInterval(strikeBell, 5200);
      // Slight delay on initial strike so masterGain has initialized
      const initialTimeout = window.setTimeout(strikeBell, 80);

      cleanup = () => {
        window.clearInterval(timer);
        window.clearTimeout(initialTimeout);
      };
    }

    this.activeTracks.set(track, { gain: masterGain, cleanup });
    return true;
  }

  public stopTrack(track: SoundTrackId): void {
    const active = this.activeTracks.get(track);
    if (!active) return;

    this.activeTracks.delete(track);
    if (this.ctx) {
      const now = this.ctx.currentTime;
      active.gain.gain.setTargetAtTime(0.0001, now, 0.08);
      window.setTimeout(() => {
        active.cleanup();
        try {
          active.gain.disconnect();
        } catch {
          // Ignore
        }
      }, 260);
    } else {
      active.cleanup();
    }
  }

  public toggleTrack(track: SoundTrackId, volume?: number): boolean {
    if (this.isTrackPlaying(track)) {
      this.stopTrack(track);
      return false;
    }
    return this.startTrack(track, volume);
  }

  public stopAllAmbient(): void {
    for (const track of Array.from(this.activeTracks.keys())) {
      this.stopTrack(track);
    }
  }

  public playBreathingChime(phase: BreathingPhase): void {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    const freqMap: Record<BreathingPhase, number> = {
      inhale: 440,
      'hold-in': 523.25,
      exhale: 392.0,
      'hold-out': 349.23,
    };

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(freqMap[phase], now);

    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.linearRampToValueAtTime(0.08, now + 0.025);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.75);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.8);
  }

  public playMeditationChime(isCompletion = false): void {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    const baseFreq = isCompletion ? 392.0 : 528.0;
    const harmonics = [
      { ratio: 1, amp: 0.14, dur: isCompletion ? 4.2 : 2.6 },
      { ratio: 2, amp: 0.05, dur: isCompletion ? 3.0 : 1.8 },
    ];

    for (const h of harmonics) {
      const osc = ctx.createOscillator();
      const g = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(baseFreq * h.ratio, now);
      g.gain.setValueAtTime(0.0001, now);
      g.gain.linearRampToValueAtTime(h.amp, now + 0.04);
      g.gain.exponentialRampToValueAtTime(0.0001, now + h.dur);
      osc.connect(g);
      g.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + h.dur + 0.05);
    }
  }

  // Alpha-range Binaural Beats (8Hz - 12Hz)
  public isBinauralPlaying(): boolean {
    return this.binauralActive;
  }

  public startBinaural(beatHz: number, volume: number): boolean {
    const ctx = this.ensureContext();
    if (!ctx) return false;

    const clampedBeat = Math.max(8, Math.min(12, beatHz));
    const clampedVol = Math.max(0, Math.min(1, volume));

    if (this.binauralActive && this.binauralRightOsc && this.binauralMasterGain) {
      this.binauralRightOsc.frequency.setTargetAtTime(
        this.binauralBaseHz + clampedBeat,
        ctx.currentTime,
        0.05
      );
      this.binauralMasterGain.gain.setTargetAtTime(clampedVol * 0.18, ctx.currentTime, 0.08);
      return true;
    }

    const masterGain = ctx.createGain();
    masterGain.gain.setValueAtTime(0.0001, ctx.currentTime);
    masterGain.connect(ctx.destination);
    masterGain.gain.setTargetAtTime(clampedVol * 0.18, ctx.currentTime, 0.25);

    const leftOsc = ctx.createOscillator();
    const rightOsc = ctx.createOscillator();
    leftOsc.type = 'sine';
    rightOsc.type = 'sine';
    leftOsc.frequency.setValueAtTime(this.binauralBaseHz, ctx.currentTime);
    rightOsc.frequency.setValueAtTime(this.binauralBaseHz + clampedBeat, ctx.currentTime);

    const leftPan = ctx.createStereoPanner();
    const rightPan = ctx.createStereoPanner();
    leftPan.pan.value = -1;
    rightPan.pan.value = 1;

    leftOsc.connect(leftPan);
    leftPan.connect(masterGain);

    rightOsc.connect(rightPan);
    rightPan.connect(masterGain);

    leftOsc.start();
    rightOsc.start();

    this.binauralLeftOsc = leftOsc;
    this.binauralRightOsc = rightOsc;
    this.binauralMasterGain = masterGain;
    this.binauralActive = true;
    return true;
  }

  public setBinauralFrequency(beatHz: number): void {
    const clampedBeat = Math.max(8, Math.min(12, beatHz));
    if (this.ctx && this.binauralRightOsc && this.binauralActive) {
      this.binauralRightOsc.frequency.setTargetAtTime(
        this.binauralBaseHz + clampedBeat,
        this.ctx.currentTime,
        0.06
      );
    }
  }

  public setBinauralVolume(volume: number): void {
    const clampedVol = Math.max(0, Math.min(1, volume));
    if (this.ctx && this.binauralMasterGain && this.binauralActive) {
      this.binauralMasterGain.gain.setTargetAtTime(clampedVol * 0.18, this.ctx.currentTime, 0.08);
    }
  }

  public stopBinaural(): void {
    if (!this.binauralActive) return;
    this.binauralActive = false;

    const left = this.binauralLeftOsc;
    const right = this.binauralRightOsc;
    const master = this.binauralMasterGain;

    this.binauralLeftOsc = null;
    this.binauralRightOsc = null;
    this.binauralMasterGain = null;

    if (this.ctx && master) {
      master.gain.setTargetAtTime(0.0001, this.ctx.currentTime, 0.08);
      window.setTimeout(() => {
        try {
          left?.stop();
          right?.stop();
          left?.disconnect();
          right?.disconnect();
          master.disconnect();
        } catch {
          // Ignore
        }
      }, 220);
    } else {
      try {
        left?.stop();
        right?.stop();
      } catch {
        // Ignore
      }
    }
  }

  public stopEverything(): void {
    this.stopAllAmbient();
    this.stopBinaural();
  }
}

export const soundEngine = new ZenSoundEngine();
