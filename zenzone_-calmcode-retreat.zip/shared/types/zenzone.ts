export type SoundTrackId = 'rain' | 'birds' | 'whitenoise' | 'bells';

export type BreathingPhase = 'inhale' | 'hold-in' | 'exhale' | 'hold-out';

export type AffirmationSituation =
  | 'before-exam'
  | 'imposter-syndrome'
  | 'late-night-fatigue'
  | 'result-anxiety'
  | 'general-confidence';

export interface UserPreferences {
  studyIntervalMinutes: number;
  preferredMeditationMinutes: number;
  breathingChimesEnabled: boolean;
  soundVolumes: Record<SoundTrackId, number>;
  binauralFrequencyHz: number;
  binauralVolume: number;
}

export interface UserProfile {
  id: number;
  username: string;
  created_at: string;
  preferences: UserPreferences;
}

export interface MoodLog {
  id: number;
  stress_level: number;
  mood_emoji: string;
  reflection: string;
  created_at: string;
}

export interface WeeklyStressPoint {
  date: string;
  label: string;
  avgStress: number | null;
  entryCount: number;
}

export interface MeditationSession {
  id: number;
  duration: number;
  completed: boolean;
  session_date: string;
}

export interface MeditationSummary {
  sessions: MeditationSession[];
  currentStreak: number;
  totalMinutes: number;
  totalSessions: number;
}

export interface CampusCalmMessage {
  id: number;
  message: string;
  topic: string;
  support_count: number;
  created_at: string;
}

export interface FavoriteAffirmation {
  id: number;
  affirmation: string;
  situation: AffirmationSituation;
  source: 'gemini' | 'local';
  created_at: string;
}

export interface YogaPose {
  id: string;
  name: string;
  focusArea: string;
  illustrationKey:
    | 'neck-stretch'
    | 'spinal-twist'
    | 'shoulder-rolls'
    | 'wrist-stretch'
    | 'forward-bend'
    | 'eye-relaxation'
    | 'side-stretch'
    | 'upper-back-stretch'
    | 'seated-cat-cow'
    | 'ankle-rotations';
  durationSeconds: number;
  steps: string[];
  breathingPrompt: string;
  benefits: string[];
}

export interface ReflectionPrompt {
  id: number;
  category: string;
  prompt: string;
}
