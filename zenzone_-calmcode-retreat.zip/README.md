# ZenZone: CalmCode Retreat

A lightweight, Scandinavian-inspired stress-relief web companion built for university students navigating examination periods, prolonged screen time, and study fatigue.

## Features Implemented

1. **Interactive Box Breathing Visualizer** — Unified `requestAnimationFrame` 4-4-4-4 timing loop (Inhale 4s, Hold 4s, Exhale 4s, Hold 4s) synchronizing circle scale, countdown, instructions, and optional Web Audio transition chimes.
2. **Exam Panic SOS Mode** — Distraction-free full-screen crisis de-escalation overlay with gentle procedural rain audio, guided breathing, step-by-step grounding cues, 2-minute / 60-second demo countdown, and before/after stress check-in saved straight to SQLite and the Chart.js weekly chart.
3. **Curated Micro-Yoga Pose Gallery** — Structured JSON dataset (`src/data/yogaPoses.json`) of 10 desk-friendly poses with custom SVG illustrations, instructions, breathing prompts, benefits, and per-pose countdown timers.
4. **Ambient Soundscape Generator** — HTML5 Web Audio API multi-track mixer for Gentle Rain, Forest Birds, White Noise, and Temple Bells with independent volume sliders and smooth transitions.
5. **Daily Mood & Stress Journal** — Persistent SQLite + LocalStorage check-in system with 1–5 stress slider, mood emoji selector, 20 exam-season reflection prompts (`src/data/reflectionPrompts.json`), edit/delete support, empty state, and live Chart.js 7-day trend visualization.
6. **Guided Meditation Timer** — Customizable 2–10 minute meditation sessions with interval singing-bowl chimes, session history, and daily streak tracking.
7. **Exam Affirmation Generator** — Situation-tailored encouragements powered by `@google/genai` when `GEMINI_API_KEY` is configured on the server, with a deterministic local affirmation engine fallback and SQLite favorite bookmarking.
8. **Alpha Binaural Beats Player** — Stereo Web Audio 8 Hz–12 Hz binaural generator with headphone guidance and wellness disclaimer.
9. **45-Minute Posture Break Screen Dimmer** — Continuous study timer using Page Visibility awareness that gently dims the screen after 45 minutes without interrupting active breathing, meditation, or SOS sessions.
10. **Anonymous Campus Calm Wall** — Moderated student encouragement bulletin board backed by Express and SQLite.

## Tech Stack

- **Frontend**: React 19, TypeScript, Tailwind CSS v4, Chart.js (`react-chartjs-2`), Lucide Icons, HTML5 Web Audio API
- **Backend**: Node.js, Express, TypeScript (`tsx` / Node 22)
- **Database**: SQLite (`better-sqlite3`, schema in `backend/database/init.sql`)

## Running Locally in Visual Studio Code

1. **Prerequisites**: Install Node.js v22+ and npm.
2. **Open in VS Code**:
   ```bash
   code .
   ```
3. **Install dependencies**:
   ```bash
   npm install
   ```
4. **Optional AI Configuration**:
   Copy `.env.example` to `.env` and optionally provide `GEMINI_API_KEY`. Without a key, the Exam Affirmation Generator uses its deterministic local pool automatically.
5. **Start the full-stack development server** (Express API + Vite frontend on port `3000`):
   ```bash
   npm run dev
   ```
6. **Open in browser**: Navigate to `http://localhost:3000`.
7. **Production build & start**:
   ```bash
   npm run build
   npm start
   ```

## Hackathon Demonstration Flow

1. Click **Exam Panic SOS** from the navigation bar or welcome hero.
2. Observe full-screen calm mode launch with synchronized 4-4-4-4 Box Breathing and gentle rain ambience.
3. Switch to **60s demo** or click **Complete & Rate Stress**, adjust before (`5`) and after (`2`) stress levels, and click **Save to Mood Journal**.
4. Return to **Mood Journal** to see the new entry persisted in SQLite and reflected immediately in the Chart.js weekly stress chart.
